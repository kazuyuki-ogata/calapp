--�����Ɏ��s�ς݂̂��ߐV���Ɏ��s�s�v

CREATE VIEW milscm_general.v_feasibility_mt_shisetsu_contract as 
SELECT
    c.facility_id
    , c.facility_id_mml
    , c.facility_name
    , c.facility_contract_start
    , CASE 
        WHEN coalesce(c.facility_contract_end, '') <> '' 
            THEN c.facility_contract_end 
        ELSE to_char(now() - '3 months' ::INTERVAL, 'YYYYMMDD') 
        END AS facility_contract_end
    , c.size 
FROM
    milscm4.mt_shori_shisetsu c 
WHERE
    c.shori_f = TRUE 
    AND c.feasibility_f = TRUE;
