--DROP TABLE  milscm_2023_006.mdv_202310_mt_shikkan;
CREATE TABLE milscm_2023_006.mdv_202310_mt_shikkan( 
    icd10_l_name TEXT NOT NULL                  -- ICD10��敪����
    , icd10_s_cd TEXT NOT NULL                  -- ICD10���敪
    , icd10_s_name TEXT NOT NULL                -- ICD10���敪����
    , icd10_code TEXT                           -- ICD10
    , icd10_name TEXT                           -- ICD10����
    , icd10_2 TEXT                              -- ICD10_2
    , icd10_2003 TEXT                           -- ICD10_2003
    , icd10_2003_2 TEXT                         -- ICD10_2003_2
    , shobyo_name_cd TEXT NOT NULL              -- ���a���R�[�h
    , shobyo_name TEXT NOT NULL                 -- ���a��
    , non_ap_f TEXT                             -- �ΏۊO�t���O
    , add_f TEXT                                -- �ǉ��t���O
); 

ALTER TABLE ONLY milscm_2023_006.mdv_202310_mt_shikkan ADD CONSTRAINT mdv_202310_mt_shikkan_pkey PRIMARY
 KEY (shobyo_name_cd); 

ALTER TABLE milscm_2023_006.mdv_202310_mt_shikkan OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_006.mdv_202310_mt_shikkan IS '�����}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_l_name IS 'ICD10��敪����'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_s_cd IS 'ICD10���敪'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_s_name IS 'ICD10���敪����'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_code IS 'ICD10'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_name IS 'ICD10����'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_2 IS 'ICD10_2'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_2003 IS 'ICD10_2003'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.icd10_2003_2 IS 'ICD10_2003_2'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.shobyo_name_cd IS '���a���R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.shobyo_name IS '���a��'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.non_ap_f IS '�ΏۊO�t���O'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_mt_shikkan.add_f IS '�ǉ��t���O';
