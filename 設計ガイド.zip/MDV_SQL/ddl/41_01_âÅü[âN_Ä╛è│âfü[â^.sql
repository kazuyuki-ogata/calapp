--DROP TABLE  milscm_2023_006.mdv_202310_work_shikkan_data;
CREATE TABLE milscm_2023_006.mdv_202310_work_shikkan_data( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , shikibetsu_no TEXT NOT NULL               -- �f�[�^���ʔԍ�
    , YEAR TEXT NOT NULL                        -- �Ώ۔N
    , shobyo_name_cd TEXT NOT NULL              -- ���a���R�[�h
    , icd10_l_name TEXT NOT NULL                -- ICD10��敪����
    , icd10_s_cd TEXT NOT NULL                  -- ICD10���敪
    , icd10_s_name TEXT NOT NULL                -- ICD10���敪����
); 

ALTER TABLE ONLY milscm_2023_006.mdv_202310_work_shikkan_data ADD CONSTRAINT mdv_202310_work_shikkan_data_pkey
 PRIMARY KEY ( 
    facility_id
    , shikibetsu_no
    , YEAR
    , shobyo_name_cd
); 

ALTER TABLE milscm_2023_006.mdv_202310_work_shikkan_data OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_006.mdv_202310_work_shikkan_data IS '���[�N_�����f�[�^'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_work_shikkan_data.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_work_shikkan_data.shikibetsu_no IS '�f�[�^���ʔԍ�'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_work_shikkan_data.YEAR IS '�Ώ۔N'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_work_shikkan_data.shobyo_name_cd IS '���a���R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_work_shikkan_data.icd10_l_name IS 'ICD10��敪����'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_work_shikkan_data.icd10_s_cd IS 'ICD10���敪'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_work_shikkan_data.icd10_s_name IS 'ICD10���敪����';
