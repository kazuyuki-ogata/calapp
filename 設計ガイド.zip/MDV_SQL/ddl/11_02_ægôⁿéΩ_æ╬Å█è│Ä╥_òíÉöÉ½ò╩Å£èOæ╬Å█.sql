--DROP TABLE  milscm_2023_006.mdv_202310_enroll_target_kanja_mixed_gender;
CREATE TABLE milscm_2023_006.mdv_202310_enroll_target_kanja_mixed_gender( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , shikibetsu_no TEXT NOT NULL               -- �f�[�^���ʔԍ�
); 

ALTER TABLE ONLY milscm_2023_006.mdv_202310_enroll_target_kanja_mixed_gender ADD CONSTRAINT mdv_202310_enroll_target_kanja_mixed_gender_pkey
 PRIMARY KEY (facility_id, shikibetsu_no); 

ALTER TABLE milscm_2023_006.mdv_202310_enroll_target_kanja_mixed_gender OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_006.mdv_202310_enroll_target_kanja_mixed_gender IS '�g����_�Ώۊ���_�������ʏ��O�Ώ�'
; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_enroll_target_kanja_mixed_gender.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_006.mdv_202310_enroll_target_kanja_mixed_gender.shikibetsu_no IS '�f�[�^���ʔԍ�'
;
