-- SQL_ID : 61_01
-- �f���o��_���Ҕw�i�o�^
-- �Z���N�g_�����f�[�^_���Ҕw�i�p����w��̌����̒l�𒊏o���A�f���o��_���Ҕw�i�e�[�u���Ɋi�[����B
INSERT 
INTO milscm_2023_010.azn_202310_deli_kanja_backborn_kensa 
SELECT
    kensa.facility_id
    , kensa.himoduke_id
    , max(kensa.cate_k) AS cate_k
    , max(kensa.value_k) AS value_k
    , max(kensa.cate_cre) AS cate_cre
    , max(kensa.value_cre) AS value_cre
    , max(kensa.cate_egfr) AS cate_egfr
    , max(kensa.value_egfr) AS value_egfr
    , max(kensa.cate_ntbnp) AS cate_ntbnp
    , max(kensa.value_ntbnp) AS value_ntbnp
    , max(kensa.cate_bnp) AS cate_bnp
    , max(kensa.value_bnp) AS value_bnp 
FROM
    ( 
        SELECT
            facility_id
            , himoduke_id
            , CASE 
                WHEN disp_name = '�J���E��' 
                AND num_value ::NUMERIC < 4.5 
                    THEN '4.5����' 
                WHEN disp_name = '�J���E��' 
                AND num_value ::NUMERIC < 5 
                    THEN '4.5-5.0����' 
                WHEN disp_name = '�J���E��' 
                AND num_value ::NUMERIC < 5.5 
                    THEN '5.0-5.5����' 
                WHEN disp_name = '�J���E��' 
                AND num_value ::NUMERIC < 6 
                    THEN '5.5-6.0����' 
                WHEN disp_name = '�J���E��' 
                    THEN '6.0�ȏ�' 
                ELSE NULL 
                END AS cate_k
            , CASE 
                WHEN disp_name = '�J���E��' 
                    THEN num_value ::NUMERIC 
                ELSE NULL 
                END AS value_k
            , CASE 
                WHEN disp_name = '�����N���A�`�j��' 
                AND num_value ::NUMERIC < 2.0 
                    THEN '2.0����' 
                WHEN disp_name = '�����N���A�`�j��' 
                    THEN '2.0�ȏ�' 
                ELSE NULL 
                END AS cate_cre
            , CASE 
                WHEN disp_name = '�����N���A�`�j��' 
                    THEN num_value ::NUMERIC 
                ELSE NULL 
                END AS value_cre
            , CASE 
                WHEN disp_name = 'eGFR' 
                AND num_value ::NUMERIC < 15 
                    THEN '15����' 
                WHEN disp_name = 'eGFR' 
                AND num_value ::NUMERIC < 30 
                    THEN '15-30����' 
                WHEN disp_name = 'eGFR' 
                AND num_value ::NUMERIC < 45 
                    THEN '30-45����' 
                WHEN disp_name = 'eGFR' 
                AND num_value ::NUMERIC < 60 
                    THEN '45-60����' 
                WHEN disp_name = 'eGFR' 
                    THEN '60�ȏ�' 
                ELSE NULL 
                END AS cate_egfr
            , CASE 
                WHEN disp_name = 'eGFR' 
                    THEN num_value ::NUMERIC 
                ELSE NULL 
                END AS value_egfr
            , CASE 
                WHEN disp_name = 'NT-proBNP' 
                AND num_value ::NUMERIC < 55 
                    THEN '55����' 
                WHEN disp_name = 'NT-proBNP' 
                AND num_value ::NUMERIC < 125 
                    THEN '55-125����' 
                WHEN disp_name = 'NT-proBNP' 
                AND num_value ::NUMERIC < 300 
                    THEN '125-300����' 
                WHEN disp_name = 'NT-proBNP' 
                AND num_value ::NUMERIC < 900 
                    THEN '300-900����' 
                WHEN disp_name = 'NT-proBNP' 
                    THEN '900�ȏ�' 
                ELSE NULL 
                END AS cate_ntbnp
            , CASE 
                WHEN disp_name = 'BNP' 
                    THEN num_value ::NUMERIC 
                ELSE NULL 
                END AS value_ntbnp
            , CASE 
                WHEN disp_name = 'BNP' 
                AND num_value ::NUMERIC < 18.4 
                    THEN '18.4����' 
                WHEN disp_name = 'BNP' 
                AND num_value ::NUMERIC < 35 
                    THEN '18.4-35����' 
                WHEN disp_name = 'BNP' 
                AND num_value ::NUMERIC < 100 
                    THEN '35-100����' 
                WHEN disp_name = 'BNP' 
                AND num_value ::NUMERIC < 200 
                    THEN '100-200����' 
                WHEN disp_name = 'BNP' 
                    THEN '200�ȏ�' 
                ELSE NULL 
                END AS cate_bnp
            , CASE 
                WHEN disp_name = 'BNP' 
                    THEN num_value ::NUMERIC 
                ELSE NULL 
                END AS value_bnp 
        FROM
            milscm_2023_010.azn_202310_select_kanja_backborn_kensa
    ) kensa 
GROUP BY
    kensa.facility_id
    , kensa.himoduke_id;
