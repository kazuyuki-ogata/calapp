-- SQL_ID : 61_11
-- デリバリ_カリウム平均推移_週別_全患者登録
-- カリウムの平均推移をまとめ、デリバリ_カリウム平均推移_週別_全患者テーブルに格納する。
WITH kensa AS ( 
    SELECT
        temp_kensa.facility_id
        , temp_kensa.himoduke_id
        , temp_kensa.weeks
        , temp_kensa.num_value 
    FROM
        milscm_2023_010.azn_202310_select_kensa_k temp_kensa 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_deli_kanja_backborn_kensa AS backborn 
            WHERE
                -- cate_egfrがNULLを除く
                backborn.cate_egfr IS NOT NULL 
                AND temp_kensa.facility_id = backborn.facility_id 
                AND temp_kensa.himoduke_id = backborn.himoduke_id
        )
) 
, kensa_all AS ( 
    SELECT
        kensa.facility_id
        , kensa.himoduke_id
        , kensa.weeks
        , avg(kensa.num_value) AS num_value 
    FROM
        kensa 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_select_patient_basic kanja 
            WHERE
                -- 18歳以上
                kanja.age ::INTEGER >= 18 
                AND kensa.facility_id = kanja.facility_id 
                AND kensa.himoduke_id = kanja.himoduke_id
        ) 
    GROUP BY
        kensa.facility_id
        , kensa.himoduke_id
        , kensa.weeks
) 
INSERT 
INTO milscm_2023_010.azn_202310_deli_k_weeks_all 
SELECT
    'ALL' AS cate_egfr_summary
    , kensa_all.weeks
    , avg(kensa_all.num_value) AS avg_value
    , stddev_pop(kensa_all.num_value) AS std_value
    , count(*) AS patient_count 
FROM
    kensa_all 
GROUP BY
    kensa_all.weeks;
