-- SQL_ID : 61_16
-- デリバリ_カリウム平均推移_週別_処方期間別_lbなし登録
-- カリウムの平均推移をまとめ、デリバリ_カリウム平均推移_週別_処方期間別_lbなしテーブルに格納する。
WITH backborn AS ( 
    SELECT
        facility_id
        , himoduke_id
        , CASE 
            WHEN cate_egfr IN ('15未満', '15-30未満') 
                THEN '01_30未満' 
            WHEN cate_egfr IN ('45-60未満', '60以上') 
                THEN '03_45以上' 
            ELSE '02_30-45未満' 
            END AS cate_egfr_summary 
    FROM
        milscm_2023_010.azn_202310_deli_kanja_backborn_kensa 
    WHERE
        -- cate_egfrがNULLを除く
        cate_egfr IS NOT NULL
) 
, kensa AS ( 
    SELECT
        temp_kensa.facility_id
        , temp_kensa.himoduke_id
        , backborn.cate_egfr_summary
        , temp_kensa.weeks
        , avg(temp_kensa.num_value) AS num_value 
    FROM
        milscm_2023_010.azn_202310_select_kensa_k temp_kensa 
        INNER JOIN backborn 
            ON ( 
                temp_kensa.facility_id = backborn.facility_id 
                AND temp_kensa.himoduke_id = backborn.himoduke_id
            ) 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_select_patient_basic temp_kanja 
            WHERE
                -- 18歳以上
                temp_kanja.age ::INTEGER >= 18 
                AND temp_kensa.facility_id = temp_kanja.facility_id 
                AND temp_kensa.himoduke_id = temp_kanja.himoduke_id
        ) 
    GROUP BY
        temp_kensa.facility_id
        , temp_kensa.himoduke_id
        , backborn.cate_egfr_summary
        , temp_kensa.weeks
) 
, k_weeks AS ( 
    SELECT
        kensa.cate_egfr_summary
        , CASE 
            WHEN kanja.shoho_term BETWEEN 0 AND 15 
                THEN '01_短期' 
            WHEN kanja.shoho_term BETWEEN 16 AND 90 
                THEN '02_中期' 
            WHEN kanja.shoho_term >= 91 
                THEN '03_長期' 
            ELSE NULL 
            END AS shoho_cate
        , kensa.weeks
        , kensa.num_value 
    FROM
        kensa 
        LEFT JOIN milscm_2023_010.azn_202310_select_patient_basic kanja 
            ON kensa.facility_id = kanja.facility_id 
            AND kensa.himoduke_id = kanja.himoduke_id
) 
INSERT 
INTO milscm_2023_010.azn_202310_deli_k_weeks_shoho_term_no_lb 
SELECT
    k_weeks.cate_egfr_summary
    , k_weeks.shoho_cate
    , k_weeks.weeks
    , avg(k_weeks.num_value) AS avg_value
    , stddev_pop(k_weeks.num_value) AS std_value
    , count(*) AS patient_count 
FROM
    k_weeks 
GROUP BY
    k_weeks.cate_egfr_summary
    , k_weeks.shoho_cate
    , k_weeks.weeks;
