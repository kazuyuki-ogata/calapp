-- SQL_ID : 61_02
-- デリバリ_患者背景_サマリ登録
-- 各テーブルの集計結果をまとめ、デリバリ_患者背景_サマリテーブルに格納する。
WITH kanja AS ( 
    SELECT
        temp_kanja.facility_id
        , temp_kanja.himoduke_id
        , CASE 
            WHEN temp_kanja.age ::INTEGER < 40 
                THEN '01_40歳未満' 
            WHEN temp_kanja.age ::INTEGER >= 40 
            AND temp_kanja.age ::INTEGER < 50 
                THEN '02_40代' 
            WHEN temp_kanja.age ::INTEGER >= 50 
            AND temp_kanja.age ::INTEGER < 60 
                THEN '03_50代' 
            WHEN temp_kanja.age ::INTEGER >= 60 
            AND temp_kanja.age ::INTEGER < 70 
                THEN '04_60代' 
            WHEN temp_kanja.age ::INTEGER >= 70 
            AND temp_kanja.age ::INTEGER < 80 
                THEN '05_70代' 
            WHEN temp_kanja.age ::INTEGER >= 80 
            AND temp_kanja.age ::INTEGER < 90 
                THEN '06_80代' 
            WHEN temp_kanja.age ::INTEGER <= 90 
                THEN '07_90歳以上' 
            ELSE '' 
            END AS age_cate
        , temp_kanja.sex_kubun
        , CASE 
            WHEN temp_kanja.shoho_term <= 15 
                THEN '01_短期' 
            WHEN temp_kanja.shoho_term >= 16 
            AND temp_kanja.shoho_term <= 90 
                THEN '02_中期' 
            WHEN temp_kanja.shoho_term >= 91 
                THEN '03_長期' 
            ELSE '' 
            END AS kikan
        , temp_kanja.department
        , temp_kensa.cate_k
        , temp_kensa.cate_cre
        , temp_kensa.cate_egfr
        , temp_kensa.cate_ntbnp
        , temp_kensa.cate_bnp 
    FROM
        milscm_2023_010.azn_202310_select_patient_basic AS temp_kanja 
        LEFT JOIN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa AS temp_kensa 
            ON temp_kanja.facility_id = temp_kensa.facility_id 
            AND temp_kanja.himoduke_id = temp_kensa.himoduke_id
) 
INSERT 
INTO milscm_2023_010.azn_202310_deli_kanja_backborn_sum 
SELECT
    kanja.facility_id
    , kanja.himoduke_id
    , kanja.age_cate
    , kanja.sex_kubun
    , kanja.kikan
    , kanja.department
    , kanja.cate_k
    , kanja.cate_cre
    , kanja.cate_egfr
    , kanja.cate_ntbnp
    , kanja.cate_bnp
    , CASE 
        WHEN gappei01.d01 = 0 
            THEN 1 
        ELSE 0 
        END AS ckd_n
    , CASE 
        WHEN gappei01.d01 = 1 
        AND gappei02.d02 = 1 
            THEN 1 
        ELSE 0 
        END AS ckd_01
    , CASE 
        WHEN gappei01.d01 = 1 
        AND gappei02.d03 = 1 
            THEN 1 
        ELSE 0 
        END AS ckd_02
    , CASE 
        WHEN gappei01.d01 = 1 
        AND gappei02.d04 = 1 
            THEN 1 
        ELSE 0 
        END AS ckd_03
    , CASE 
        WHEN gappei01.d01 = 1 
        AND gappei02.d02 = 0 
        AND gappei02.d03 = 0 
        AND gappei02.d04 = 0 
            THEN 1 
        ELSE 0 
        END AS ckd_04
    , hd.hd_flg
    , yakuzai.c01
    , yakuzai.c02
    , yakuzai.c03
    , yakuzai.c04
    , yakuzai.c05
    , yakuzai.c06
    , yakuzai.c07
    , yakuzai.c08
    , yakuzai.c09
    , yakuzai.c10
    , yakuzai.c11 
FROM
    kanja 
    LEFT JOIN milscm_2023_010.azn_202310_select_kanja_backborn_gappei01 AS gappei01 
        ON ( 
            kanja.facility_id = gappei01.facility_id 
            AND kanja.himoduke_id = gappei01.himoduke_id
        ) 
    LEFT JOIN milscm_2023_010.azn_202310_select_kanja_backborn_gappei02 AS gappei02 
        ON ( 
            kanja.facility_id = gappei02.facility_id 
            AND kanja.himoduke_id = gappei02.himoduke_id
        ) 
    LEFT JOIN milscm_2023_010.azn_202310_select_kanja_backborn_hd AS hd 
        ON ( 
            kanja.facility_id = hd.facility_id 
            AND kanja.himoduke_id = hd.himoduke_id
        ) 
    LEFT JOIN milscm_2023_010.azn_202310_select_kanja_backborn_yakuzai AS yakuzai 
        ON ( 
            kanja.facility_id = yakuzai.facility_id 
            AND kanja.himoduke_id = yakuzai.himoduke_id
        );
