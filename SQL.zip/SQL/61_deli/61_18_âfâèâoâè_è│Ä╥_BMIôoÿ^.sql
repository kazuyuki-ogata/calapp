-- SQL_ID : 61_18
-- デリバリ_患者_BMI登録
-- セレクト_バイタルから身長と体重を抽出しBMIを算出した結果とあわせて、デリバリ_患者_BMIテーブルに格納する。
WITH vital AS ( 
    SELECT
        facility_id
        , himoduke_id
        , CASE 
            WHEN item_name = 'Height' 
                THEN vital_sign_num_value 
            ELSE NULL 
            END AS height
        , CASE 
            WHEN item_name = 'Weight' 
                THEN vital_sign_num_value 
            ELSE NULL 
            END AS weight 
    FROM
        milscm_2023_010.azn_202310_select_vital
) 
INSERT 
INTO milscm_2023_010.azn_202310_deli_kanja_bmi 
SELECT
    vital.facility_id
    , vital.himoduke_id
    , max(vital.height ::NUMERIC) AS height
    , max(vital.weight ::NUMERIC) AS weight
    , max(vital.weight ::NUMERIC) / ( 
        (max(vital.height ::NUMERIC) / 100.00) * (max(vital.height ::NUMERIC) / 100.00)
    ) AS bmi 
FROM
    vital 
GROUP BY
    vital.facility_id
    , vital.himoduke_id;
