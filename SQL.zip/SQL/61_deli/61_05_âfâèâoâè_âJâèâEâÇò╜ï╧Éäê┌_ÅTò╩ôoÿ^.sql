-- SQL_ID : 61_05
-- デリバリ_カリウム平均推移_週別登録
-- カリウムの平均推移をまとめ、デリバリ_カリウム平均推移_週別テーブルに格納する。
WITH backborn AS ( 
    SELECT
        facility_id
        , himoduke_id
        , CASE 
            WHEN cate_egfr IN ('15未満', '15-30未満') 
                THEN '30未満' 
            WHEN cate_egfr IN ('45-60未満', '60以上') 
                THEN '45以上' 
            ELSE '30-45未満' 
            END AS cate_egfr_summary 
    FROM
        milscm_2023_010.azn_202310_deli_kanja_backborn_kensa 
    WHERE
        -- cate_egfrがNULLを除く
        cate_egfr IS NOT NULL
) 
, k_weeks AS ( 
    SELECT
        kensa.facility_id
        , kensa.himoduke_id
        , backborn.cate_egfr_summary
        , kensa.weeks
        , avg(kensa.num_value) AS num_value 
    FROM
        milscm_2023_010.azn_202310_select_kensa_k kensa 
        INNER JOIN backborn 
            ON ( 
                kensa.facility_id = backborn.facility_id 
                AND kensa.himoduke_id = backborn.himoduke_id
            ) 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_select_patient_basic kanja 
            WHERE
                -- 18歳以上
                kanja.age ::INTEGER >= 18 
                AND kensa.facility_id = kanja.facility_id 
                AND kensa.himoduke_id = kanja.himoduke_id
        ) 
    GROUP BY
        kensa.facility_id
        , kensa.himoduke_id
        , backborn.cate_egfr_summary
        , kensa.weeks
) 
INSERT 
INTO milscm_2023_010.azn_202310_deli_k_weeks 
SELECT
    k_weeks.cate_egfr_summary
    , k_weeks.weeks
    , avg(k_weeks.num_value) AS avg_value
    , stddev_pop(k_weeks.num_value) AS std_value
    , count(*) AS patient_count 
FROM
    k_weeks 
GROUP BY
    k_weeks.cate_egfr_summary
    , k_weeks.weeks;
