-- SQL_ID : 61_10
-- デリバリ_カリウム平均推移_日別_全患者_lb30以上登録
-- カリウムの平均推移をまとめ、デリバリ_カリウム平均推移_日別_全患者_lb30以上テーブルに格納する。
WITH kensa AS ( 
    SELECT
        temp_kensa.facility_id
        , temp_kensa.himoduke_id
        , temp_kensa.days
        , temp_kensa.num_value 
    FROM
        milscm_2023_010.azn_202310_select_kensa_k temp_kensa 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_deli_kanja_backborn_kensa AS backborn 
            WHERE
                -- cate_egfrがNULLを除く
                backborn.cate_egfr IS NOT NULL 
                AND temp_kensa.facility_id = backborn.facility_id 
                AND temp_kensa.himoduke_id = backborn.himoduke_id
        )
) 
INSERT 
INTO milscm_2023_010.azn_202310_deli_k_days_all_look30 
SELECT
    'ALL' AS cate_egfr_summary
    , kensa.days
    , avg(kensa.num_value) AS avg_value
    , stddev_pop(kensa.num_value) AS std_value
    , count(*) AS patient_count 
FROM
    kensa 
WHERE
    EXISTS ( 
        SELECT
            1 
        FROM
            milscm_2023_010.azn_202310_select_patient_basic kanja 
        WHERE
            -- 18歳以上かつlook_back期間30以上
            kanja.age ::INTEGER >= 18 
            AND kanja.look_back_term >= 30 
            AND kensa.facility_id = kanja.facility_id 
            AND kensa.himoduke_id = kanja.himoduke_id
    ) 
GROUP BY
    kensa.days;
