-- SQL_ID : 21_02
-- �{�݃}�X�^�o�^
-- �g����_�Ώێ{�݃e�[�u���Ɏ{�݃}�X�NID��t�^�������ʂ��{�݃}�X�^�e�[�u���Ɋi�[����B
WITH mask AS ( 
    SELECT
        1 AS row_no
        , 'A' AS facility_mask_id 
    UNION ALL 
    SELECT
        2 AS row_no
        , 'B' AS facility_mask_id 
    UNION ALL 
    SELECT
        3 AS row_no
        , 'C' AS facility_mask_id 
    UNION ALL 
    SELECT
        4 AS row_no
        , 'D' AS facility_mask_id 
    UNION ALL 
    SELECT
        5 AS row_no
        , 'E' AS facility_mask_id 
    UNION ALL 
    SELECT
        6 AS row_no
        , 'F' AS facility_mask_id 
    UNION ALL 
    SELECT
        7 AS row_no
        , 'G' AS facility_mask_id 
    UNION ALL 
    SELECT
        8 AS row_no
        , 'H' AS facility_mask_id 
    UNION ALL 
    SELECT
        9 AS row_no
        , 'I' AS facility_mask_id 
    UNION ALL 
    SELECT
        10 AS row_no
        , 'J' AS facility_mask_id 
    UNION ALL 
    SELECT
        11 AS row_no
        , 'K' AS facility_mask_id 
    UNION ALL 
    SELECT
        12 AS row_no
        , 'L' AS facility_mask_id 
    UNION ALL 
    SELECT
        13 AS row_no
        , 'M' AS facility_mask_id 
    UNION ALL 
    SELECT
        14 AS row_no
        , 'N' AS facility_mask_id 
    UNION ALL 
    SELECT
        15 AS row_no
        , 'O' AS facility_mask_id 
    UNION ALL 
    SELECT
        16 AS row_no
        , 'P' AS facility_mask_id 
    UNION ALL 
    SELECT
        17 AS row_no
        , 'Q' AS facility_mask_id 
    UNION ALL 
    SELECT
        18 AS row_no
        , 'R' AS facility_mask_id 
    UNION ALL 
    SELECT
        19 AS row_no
        , 'S' AS facility_mask_id 
    UNION ALL 
    SELECT
        20 AS row_no
        , 'T' AS facility_mask_id 
    UNION ALL 
    SELECT
        21 AS row_no
        , 'U' AS facility_mask_id 
    UNION ALL 
    SELECT
        22 AS row_no
        , 'V' AS facility_mask_id 
    UNION ALL 
    SELECT
        23 AS row_no
        , 'W' AS facility_mask_id 
    UNION ALL 
    SELECT
        24 AS row_no
        , 'X' AS facility_mask_id 
    UNION ALL 
    SELECT
        25 AS row_no
        , 'Y' AS facility_mask_id 
    UNION ALL 
    SELECT
        26 AS row_no
        , 'Z' AS facility_mask_id
) 
INSERT 
INTO milscm_2023_010.azn_202310_mt_shisetsu 
SELECT
    mask.facility_mask_id
    , shisetsu.facility_id
    , shisetsu.facility_id_mml
    , shisetsu.facility_name
    , shisetsu.facility_contract_start
    , shisetsu.facility_contract_end
    , shisetsu.SIZE 
FROM
    ( 
        SELECT
            *
            , row_number() OVER (ORDER BY facility_id) AS row_no 
        FROM
            milscm_2023_010.azn_202310_enroll_shisetsu
    ) AS shisetsu 
    INNER JOIN mask 
        ON shisetsu.row_no = mask.row_no;
