-- SQL_ID : 41_06
-- ���[�N_�o�C�^��_MML�o�^
-- MML�̊��҃f�[�^����g���A�̏d�𒊏o���A���[�N_�o�C�^��_MML�e�[�u���Ɋi�[����B
WITH vital AS ( 
    SELECT DISTINCT
        vitalsign.facility_id
        , vitalsign.master_id
        , item.item_name
        , item.vital_sign_num_value
        , 
        LEFT (vitalsign.vital_sign_time, 8) AS vital_sign_date 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_vs_vitalsign AS vitalsign 
        INNER JOIN ( 
            SELECT
                * 
            FROM
                milscm_2023_010.azn_202310_base_merge_mml_vs_item 
            WHERE
                item_name IN ('Height', 'Weight')
        ) AS item 
            ON ( 
                vitalsign.facility_id = item.facility_id 
                AND vitalsign.master_id = item.master_id 
                AND vitalsign.uid = item.uid 
                AND vitalsign.vital_seq = item.vital_seq
            )
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_vital_mml 
SELECT
    vital.facility_id
    , kanja.himoduke_id
    , vital.item_name
    , vital.vital_sign_num_value
    , vital.vital_sign_date 
FROM
    vital 
    INNER JOIN ( 
        SELECT
            * 
        FROM
            milscm_2023_010.azn_202310_mt_kanja_id_list 
        WHERE
            data_type = 'MML'
    ) kanja 
        ON ( 
            vital.facility_id = kanja.facility_id 
            AND vital.master_id = kanja.patient_id
        ) 
WHERE
    coalesce(vital.vital_sign_num_value, '') <> ''
