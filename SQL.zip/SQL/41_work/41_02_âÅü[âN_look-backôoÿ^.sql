-- SQL_ID : 41_02
-- ���[�N_look-back�o�^
-- DPC�̊��҃f�[�^�𒊏o���A���[�N_look-back�e�[�u���Ɋi�[����B
WITH dpc_efn AS ( 
    SELECT
        facility_id
        , shikibetsu_no
        , jisshi_ymd 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_efn 
    WHERE
        shinryo_ym = 
        LEFT (jisshi_ymd, 6)
) 
, dpc_efg AS ( 
    SELECT
        facility_id
        , shikibetsu_no
        , jisshi_ymd 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_efg 
    WHERE
        shinryo_ym = 
        LEFT (jisshi_ymd, 6)
) 
, dpc_union AS ( 
    SELECT
        facility_id
        , shikibetsu_no
        , jisshi_ymd 
    FROM
        dpc_efn 
    UNION ALL 
    SELECT
        facility_id
        , shikibetsu_no
        , jisshi_ymd 
    FROM
        dpc_efg
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_look_back 
SELECT
    dpc_union.facility_id
    , dpc_union.shikibetsu_no AS himoduke_id
    , min(dpc_union.jisshi_ymd) AS min_jisshi_ymd 
FROM
    dpc_union 
GROUP BY
    dpc_union.facility_id
    , dpc_union.shikibetsu_no;
