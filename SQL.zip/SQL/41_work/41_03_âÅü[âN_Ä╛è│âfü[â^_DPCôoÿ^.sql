-- SQL_ID : 41_03
-- ���[�N_�����f�[�^_DPC�o�^
-- DPC�̎����f�[�^�i�^���������j�𒊏o���A�����}�X�^�ɓo�^����Ă��鎾���R�[�h�̃f�[�^�����[�N_�����f�[�^_DPC�e�[�u���Ɋi�[����B
WITH dpc_efn AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , receipt_densan_code AS shobyo_code
        , nyuin_ymd AS shinryo_start_date
        , sinryo_meisai_name AS shobyo_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_efn 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        sinryo_meisai_name !~ '�^��'
) 
, dpc_efg AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , receipt_densan_code AS shobyo_code
        , gairai_ymd AS shinryo_start_date
        , sinryo_meisai_name AS shobyo_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_efg 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        sinryo_meisai_name !~ '�^��'
) 
, dpc_ff1_a006010 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006010_shobyo_code
        , a006010_icd10_code
        , a000020_nyuin_ymd
        , a006010_main_shobyo_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_ff1 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        a006010_main_shobyo_name !~ '�^��'
) 
, dpc_ff1_a006020 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006020_shobyo_code
        , a006020_icd10_code
        , a000020_nyuin_ymd
        , a006020_nyuin_shobyo_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_ff1 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        a006020_nyuin_shobyo_name !~ '�^��'
) 
, dpc_ff1_a006030 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006030_shobyo_code
        , a006030_icd10_code
        , a000020_nyuin_ymd
        , a006030_iryo1_shobyo_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_ff1 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        a006030_iryo1_shobyo_name !~ '�^��'
) 
, dpc_ff1_a006031 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006031_shobyo_code
        , a006031_icd10_code
        , a000020_nyuin_ymd
        , a006031_iryo2_shobyo_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_ff1 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        a006031_iryo2_shobyo_name !~ '�^��'
) 
, dpc_ff1_a006040 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , shobyo_code
        , icd10_code
        , nyuin_ymd
        , nyuin_heizonsho_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_ff1_a006040 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        nyuin_heizonsho_name !~ '�^��'
) 
, dpc_ff1_a006050 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , shobyo_code
        , icd10_code
        , nyuin_ymd
        , nyuin_shikkan_name 
    FROM
        milscm_2023_010.azn_202310_base_merge_dpc_ff1_a006050 
    WHERE
        --�a�����u�^���v�ŏI�����̂�����
        nyuin_shikkan_name !~ '�^��'
) 
, dpc_ff1_a006010_syobyo AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006010_shobyo_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006010_main_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006010
) 
, dpc_ff1_a006010_icd10 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006010_icd10_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006010_main_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006010
) 
, dpc_ff1_a006020_syobyo AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006020_shobyo_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006020_nyuin_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006020
) 
, dpc_ff1_a006020_icd10 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006020_icd10_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006020_nyuin_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006020
) 
, dpc_ff1_a006030_syobyo AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006030_shobyo_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006030_iryo1_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006030
) 
, dpc_ff1_a006030_icd10 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006030_icd10_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006030_iryo1_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006030
) 
, dpc_ff1_a006031_syobyo AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006031_shobyo_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006031_iryo2_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006031
) 
, dpc_ff1_a006031_icd10 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , a006031_icd10_code AS shobyo_code
        , a000020_nyuin_ymd AS shinryo_start_date
        , a006031_iryo2_shobyo_name AS shobyo_name 
    FROM
        dpc_ff1_a006031
) 
, dpc_ff1_a006040_syobyo AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , shobyo_code
        , nyuin_ymd AS shinryo_start_date
        , nyuin_heizonsho_name AS shobyo_name 
    FROM
        dpc_ff1_a006040
) 
, dpc_ff1_a006040_icd10 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , icd10_code AS shobyo_code
        , nyuin_ymd AS shinryo_start_date
        , nyuin_heizonsho_name AS shobyo_name 
    FROM
        dpc_ff1_a006040
) 
, dpc_ff1_a006050_syobyo AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , shobyo_code
        , nyuin_ymd AS shinryo_start_date
        , nyuin_shikkan_name AS shobyo_name 
    FROM
        dpc_ff1_a006050
) 
, dpc_ff1_a006050_icd10 AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , icd10_code AS shobyo_code
        , nyuin_ymd AS shinryo_start_date
        , nyuin_shikkan_name AS shobyo_name 
    FROM
        dpc_ff1_a006050
) 
, dpc_union AS ( 
    SELECT DISTINCT
        dpc_work.facility_id
        , dpc_work.shikibetsu_no
        , dpc_work.shobyo_code
        , dpc_work.shinryo_start_date 
    FROM
        ( 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_efn 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_efg 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006010_syobyo 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006010_icd10 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006020_syobyo 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006020_icd10 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006030_syobyo 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006030_icd10 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006031_syobyo 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006031_icd10 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006040_syobyo 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006040_icd10 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006050_syobyo 
            UNION ALL 
            SELECT
                facility_id
                , shikibetsu_no
                , shobyo_code
                , shinryo_start_date
                , shobyo_name 
            FROM
                dpc_ff1_a006050_icd10
        ) AS dpc_work
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_shikkan_dpc 
SELECT
    dpc_union.facility_id
    , dpc_union.shikibetsu_no
    , dpc_union.shobyo_code
    , dpc_union.shinryo_start_date
    , mt_shikkan.disp_name 
FROM
    dpc_union 
    INNER JOIN milscm_2023_010.azn_202310_mt_shikkan AS mt_shikkan 
        ON (dpc_union.shobyo_code = mt_shikkan.shobyo_name_cd);
