-- SQL_ID : 41_10
-- ���[�N_���̌����f�[�^_�X�L�[�}4�o�^
-- MML�i�X�L�[�}4�j�̌��̌����f�[�^�𒊏o���A���[�N_���̌����f�[�^_�X�L�[�}4�e�[�u���Ɋi�[����B
WITH mt_kensa AS ( 
    SELECT DISTINCT
        shisetsu.facility_id_mml
        , kensa.specimen_name
        , kensa.sp_code
        , kensa.item_name
        , kensa.item_code 
    FROM
        milscm_2023_010.azn_202310_mt_kensa AS kensa 
        LEFT JOIN milscm_2023_010.azn_202310_mt_shisetsu AS shisetsu 
            ON (kensa.facility_id = shisetsu.facility_id)
) 
, text_mmllb_body AS ( 
    SELECT DISTINCT
        lb_body.zip_no
        , lb_body.file_no
        , lb_body.body_no
        , lb_body.facility_id_mml
        , lb_body.master_id
        , COALESCE(lb_body.sample_time, '') AS sample_time
        , COALESCE(lb_body.regist_time, '') AS regist_time
        , COALESCE(lb_body.report_time, '') AS report_time 
    FROM
        milscm_2023_010.azn_202310_base_text_mml_mmllb_body AS lb_body 
        INNER JOIN ( 
            SELECT
                zip_no
                , file_no
                , body_no 
            FROM
                milscm_2023_010.azn_202310_base_text_mml_common 
            WHERE
                new_f IS TRUE 
                AND mml_type = 'mmlLb'
        ) AS common 
            ON ( 
                lb_body.zip_no = common.zip_no 
                AND lb_body.file_no = common.file_no 
                AND lb_body.body_no = common.body_no
            ) 
    WHERE
        lb_body.report_status = '�ŏI��' 
        OR lb_body.status_code = 'final'
) 
, text_mmllb_labo_test_temp AS ( 
    SELECT DISTINCT
        zip_no
        , file_no
        , body_no
        , facility_id_mml
        , master_id
        , labo_test_no
        , COALESCE(specimen_name, '') AS specimen_name
        , COALESCE(sp_code, '') AS sp_code 
    FROM
        milscm_2023_010.azn_202310_base_text_mml_mmllb_labo_test
) 
, text_mmllb_labo_test AS ( 
    SELECT
        text_mmllb_labo_test_temp.zip_no
        , text_mmllb_labo_test_temp.file_no
        , text_mmllb_labo_test_temp.body_no
        , text_mmllb_labo_test_temp.facility_id_mml
        , text_mmllb_labo_test_temp.master_id
        , text_mmllb_labo_test_temp.labo_test_no
        , text_mmllb_labo_test_temp.specimen_name
        , text_mmllb_labo_test_temp.sp_code 
    FROM
        text_mmllb_labo_test_temp 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                mt_kensa 
            WHERE
                text_mmllb_labo_test_temp.facility_id_mml = mt_kensa.facility_id_mml 
                AND text_mmllb_labo_test_temp.specimen_name = mt_kensa.specimen_name 
                AND text_mmllb_labo_test_temp.sp_code = mt_kensa.sp_code
        )
) 
, text_mmllb_item_temp AS ( 
    SELECT DISTINCT
        zip_no
        , file_no
        , body_no
        , facility_id_mml
        , master_id
        , labo_test_no
        , COALESCE(item_name, '') AS item_name
        , COALESCE(item_code, '') AS facility_it_code
        , COALESCE(unit, '') AS unit
        , COALESCE(value, '') AS value
        , COALESCE(num_value, '') AS num_value 
    FROM
        milscm_2023_010.azn_202310_base_text_mml_mmllb_item
) 
, text_mmllb_item AS ( 
    SELECT
        text_mmllb_item_temp.zip_no
        , text_mmllb_item_temp.file_no
        , text_mmllb_item_temp.body_no
        , text_mmllb_item_temp.facility_id_mml
        , text_mmllb_item_temp.master_id
        , text_mmllb_item_temp.labo_test_no
        , text_mmllb_item_temp.item_name
        , text_mmllb_item_temp.facility_it_code
        , text_mmllb_item_temp.unit
        , text_mmllb_item_temp.value
        , text_mmllb_item_temp.num_value 
    FROM
        text_mmllb_item_temp 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                mt_kensa 
            WHERE
                text_mmllb_item_temp.facility_id_mml = mt_kensa.facility_id_mml 
                AND text_mmllb_item_temp.item_name = mt_kensa.item_name 
                AND text_mmllb_item_temp.facility_it_code = mt_kensa.item_code
        )
) 
, mml_lb_join AS ( 
    SELECT
        text_mmllb_body.facility_id_mml
        , text_mmllb_body.master_id
        , text_mmllb_labo_test.specimen_name
        , text_mmllb_labo_test.sp_code
        , text_mmllb_item.item_name
        , text_mmllb_item.facility_it_code
        , text_mmllb_item.unit
        , text_mmllb_body.sample_time
        , text_mmllb_body.report_time
        , text_mmllb_body.regist_time
        , text_mmllb_item.value
        , text_mmllb_item.num_value 
    FROM
        text_mmllb_body 
        INNER JOIN text_mmllb_labo_test 
            ON ( 
                text_mmllb_body.zip_no = text_mmllb_labo_test.zip_no 
                AND text_mmllb_body.file_no = text_mmllb_labo_test.file_no 
                AND text_mmllb_body.body_no = text_mmllb_labo_test.body_no
            ) 
        INNER JOIN text_mmllb_item 
            ON ( 
                text_mmllb_labo_test.zip_no = text_mmllb_item.zip_no 
                AND text_mmllb_labo_test.file_no = text_mmllb_item.file_no 
                AND text_mmllb_labo_test.body_no = text_mmllb_item.body_no 
                AND text_mmllb_labo_test.labo_test_no = text_mmllb_item.labo_test_no
            )
) 
, mml_lb AS ( 
    SELECT
        * 
    FROM
        mml_lb_join 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                mt_kensa 
            WHERE
                mml_lb_join.facility_id_mml = mt_kensa.facility_id_mml 
                AND mml_lb_join.specimen_name = mt_kensa.specimen_name 
                AND mml_lb_join.sp_code = mt_kensa.sp_code 
                AND mml_lb_join.item_name = mt_kensa.item_name 
                AND mml_lb_join.facility_it_code = mt_kensa.item_code
        )
) 
, id_list AS ( 
    SELECT
        * 
    FROM
        milscm_2023_010.azn_202310_mt_kanja_id_list 
    WHERE
        -- �f�[�^��ʂ�MML
        data_type = 'MML'
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_kensa_scm4 
SELECT
    id_list.facility_id
    , id_list.himoduke_id
    , mml_lb.specimen_name
    , mml_lb.sp_code
    , mml_lb.item_name
    , mml_lb.facility_it_code
    , mml_lb.unit
    , mml_lb.sample_time
    , mml_lb.value
    , mml_lb.num_value
    , rank() OVER ( 
        PARTITION BY
            id_list.facility_id
            , id_list.himoduke_id
            , mml_lb.specimen_name
            , mml_lb.sp_code
            , mml_lb.item_name
            , mml_lb.facility_it_code
            , mml_lb.unit
            , mml_lb.sample_time 
        ORDER BY
            mml_lb.report_time DESC
            , mml_lb.regist_time DESC
    ) 
FROM
    mml_lb 
    INNER JOIN id_list 
        ON ( 
            mml_lb.facility_id_mml = id_list.facility_id_mml 
            AND mml_lb.master_id = id_list.patient_id
        );
