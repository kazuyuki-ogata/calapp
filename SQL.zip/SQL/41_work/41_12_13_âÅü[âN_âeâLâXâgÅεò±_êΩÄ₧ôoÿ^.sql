-- SQL_ID : 41_12_13
-- ���[�N_�e�L�X�g���_�ꎞ�o�^
-- MML�̃e�L�X�g�f�[�^�𒊏o���A���[�N_�e�L�X�g���_�ꎞ�e�[�u���Ɋi�[����B
WITH merge_mml_sm_clinical_course AS ( 
    SELECT
        facility_id
        , master_id
        , uid
        , summary_seq
        , keika_seq
        , shinryo_ymd
        , 
        LEFT (event_date, 8) AS event_date
        , keika_kiroku 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_sm_clinical_course 
    WHERE
        -- �o�ߋL�^��NULL�A�󔒂�����
        COALESCE(keika_kiroku, '') <> ''
) 
, mml_sm_join AS ( 
    SELECT
        merge_mml_sm_clinical_course.facility_id
        , merge_mml_sm_clinical_course.master_id
        , merge_mml_sm_clinical_course.uid
        , merge_mml_sm_clinical_course.summary_seq AS module_seq
        , 1 AS problem_seq
        , 1 AS assessment_item_seq
        , 1 AS gaibu_sansyo_seq
        , merge_mml_sm_clinical_course.keika_seq
        , 'sm' AS source_module
        , 'clinical_course' AS source_table
        , 'keika_kiroku' AS source_column
        , merge_mml_sm_clinical_course.shinryo_ymd AS comfirm_date
        , merge_mml_sm_clinical_course.event_date
        , merge_mml_sm_summary.history_start_ymd
        , merge_mml_sm_summary.history_end_ymd
        , merge_mml_sm_clinical_course.keika_kiroku AS original_text
        , 0 AS chief_complaint_f 
    FROM
        merge_mml_sm_clinical_course 
        INNER JOIN milscm_2023_010.azn_202310_base_merge_mml_sm_summary AS merge_mml_sm_summary 
            ON ( 
                merge_mml_sm_clinical_course.facility_id = merge_mml_sm_summary.facility_id 
                AND merge_mml_sm_clinical_course.master_id = merge_mml_sm_summary.master_id 
                AND merge_mml_sm_clinical_course.uid = merge_mml_sm_summary.uid 
                AND merge_mml_sm_clinical_course.summary_seq = merge_mml_sm_summary.summary_seq
            )
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_text_temp 
SELECT
    mml_sm_join.facility_id
    , mml_sm_join.master_id
    , mml_sm_join.uid
    , mml_sm_join.module_seq
    , mml_sm_join.problem_seq
    , mml_sm_join.assessment_item_seq
    , mml_sm_join.gaibu_sansyo_seq
    , mml_sm_join.keika_seq
    , mml_sm_join.source_module
    , mml_sm_join.source_table
    , mml_sm_join.source_column
    , mml_sm_join.comfirm_date
    , mml_sm_join.event_date
    , mml_sm_join.history_start_ymd
    , mml_sm_join.history_end_ymd
    , mml_sm_join.original_text
    , mml_sm_join.chief_complaint_f 
FROM
    mml_sm_join;
