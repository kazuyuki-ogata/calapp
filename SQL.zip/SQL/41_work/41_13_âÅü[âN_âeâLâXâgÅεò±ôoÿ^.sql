-- SQL_ID : 41_13
-- ���[�N_�e�L�X�g���o�^
-- MML�̃e�L�X�g�f�[�^�𒊏o���A���[�N_�e�L�X�g���e�[�u���Ɋi�[����B
WITH kanja AS ( 
    SELECT DISTINCT
        facility_id
        , himoduke_id
        , patient_id 
    FROM
        milscm_2023_010.azn_202310_mt_kanja_id_list 
    WHERE
        -- �f�[�^��ʂ�MML
        data_type = 'MML'
) 
, input_data AS ( 
    SELECT
        work_text_temp.facility_id
        , kanja.himoduke_id
        , work_text_temp.uid
        , work_text_temp.module_seq
        , work_text_temp.problem_seq
        , work_text_temp.assessment_item_seq
        , work_text_temp.gaibu_sansyo_seq
        , work_text_temp.keika_seq
        , work_text_temp.source_module
        , work_text_temp.source_table
        , work_text_temp.source_column
        , work_text_temp.comfirm_date
        , work_text_temp.event_date
        , work_text_temp.history_start_ymd
        , work_text_temp.history_end_ymd
        , work_text_temp.original_text
        , work_text_temp.chief_complaint_f 
    FROM
        milscm_2023_010.azn_202310_work_text_temp AS work_text_temp 
        INNER JOIN kanja 
            ON ( 
                work_text_temp.facility_id = kanja.facility_id 
                AND work_text_temp.master_id = kanja.patient_id
            )
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_text 
SELECT
    input_data.facility_id
    , input_data.himoduke_id
    , ROW_NUMBER() OVER ( 
        ORDER BY
            input_data.facility_id
            , input_data.himoduke_id
            , input_data.comfirm_date
    ) AS link_no
    , input_data.uid
    , input_data.module_seq
    , input_data.problem_seq
    , input_data.assessment_item_seq
    , input_data.gaibu_sansyo_seq
    , input_data.keika_seq
    , input_data.source_module
    , input_data.source_table
    , input_data.source_column
    , input_data.comfirm_date
    , input_data.event_date
    , input_data.history_start_ymd
    , input_data.history_end_ymd
    , input_data.original_text
    , input_data.chief_complaint_f
    , ROW_NUMBER() OVER ( 
        PARTITION BY
            input_data.facility_id
            , input_data.himoduke_id
            , input_data.original_text 
        ORDER BY
            input_data.comfirm_date ::DATE ASC
    ) AS dup_text_seq 
FROM
    input_data;
