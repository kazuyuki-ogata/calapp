-- SQL_ID : 41_12_02
-- ���[�N_�e�L�X�g���_�ꎞ�o�^
-- MML�̃e�L�X�g�f�[�^�𒊏o���A���[�N_�e�L�X�g���_�ꎞ�e�[�u���Ɋi�[����B
WITH merge_mml_pc_assessment AS ( 
    SELECT
        facility_id
        , master_id
        , uid
        , keika_seq AS module_seq
        , problem_seq
        , assessment_item_seq
        , 1 AS gaibu_sansyo_seq
        , 1 AS keika_seq
        , 'pc' AS source_module
        , 'assessment' AS source_table
        , 'assessment_item' AS source_column
        , shinryo_ymd AS comfirm_date
        , NULL AS event_date
        , NULL AS history_start_ymd
        , NULL AS history_end_ymd
        , assessment_item AS original_text
        , 0 AS chief_complaint_f 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_pc_assessment 
    WHERE
        -- �A�Z�X�����g��NULL�A�󔒂�����
        COALESCE(assessment_item, '') <> ''
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_text_temp 
SELECT
    merge_mml_pc_assessment.facility_id
    , merge_mml_pc_assessment.master_id
    , merge_mml_pc_assessment.uid
    , merge_mml_pc_assessment.module_seq
    , merge_mml_pc_assessment.problem_seq
    , merge_mml_pc_assessment.assessment_item_seq
    , merge_mml_pc_assessment.gaibu_sansyo_seq
    , merge_mml_pc_assessment.keika_seq
    , merge_mml_pc_assessment.source_module
    , merge_mml_pc_assessment.source_table
    , merge_mml_pc_assessment.source_column
    , merge_mml_pc_assessment.comfirm_date
    , merge_mml_pc_assessment.event_date
    , merge_mml_pc_assessment.history_start_ymd
    , merge_mml_pc_assessment.history_end_ymd
    , merge_mml_pc_assessment.original_text
    , merge_mml_pc_assessment.chief_complaint_f 
FROM
    merge_mml_pc_assessment;
