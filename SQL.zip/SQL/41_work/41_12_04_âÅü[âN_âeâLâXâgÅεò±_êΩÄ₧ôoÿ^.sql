-- SQL_ID : 41_12_04
-- ���[�N_�e�L�X�g���_�ꎞ�o�^
-- MML�̃e�L�X�g�f�[�^�𒊏o���A���[�N_�e�L�X�g���_�ꎞ�e�[�u���Ɋi�[����B
WITH merge_mml_pc_problem AS ( 
    SELECT
        facility_id
        , master_id
        , uid
        , keika_seq AS module_seq
        , problem_seq
        , 1 AS assessment_item_seq
        , 1 AS gaibu_sansyo_seq
        , 1 AS keika_seq
        , 'pc' AS source_module
        , 'problem' AS source_table
        , 'problem_shippei_name' AS source_column
        , shinryo_ymd AS comfirm_date
        , NULL AS event_date
        , NULL AS history_start_ymd
        , NULL AS history_end_ymd
        , problem_shippei_name AS original_text
        , 0 AS chief_complaint_f 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_pc_problem 
    WHERE
        -- �v���u�������i���a���j��NULL�A�󔒂�����
        COALESCE(problem_shippei_name, '') <> ''
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_text_temp 
SELECT
    merge_mml_pc_problem.facility_id
    , merge_mml_pc_problem.master_id
    , merge_mml_pc_problem.uid
    , merge_mml_pc_problem.module_seq
    , merge_mml_pc_problem.problem_seq
    , merge_mml_pc_problem.assessment_item_seq
    , merge_mml_pc_problem.gaibu_sansyo_seq
    , merge_mml_pc_problem.keika_seq
    , merge_mml_pc_problem.source_module
    , merge_mml_pc_problem.source_table
    , merge_mml_pc_problem.source_column
    , merge_mml_pc_problem.comfirm_date
    , merge_mml_pc_problem.event_date
    , merge_mml_pc_problem.history_start_ymd
    , merge_mml_pc_problem.history_end_ymd
    , merge_mml_pc_problem.original_text
    , merge_mml_pc_problem.chief_complaint_f 
FROM
    merge_mml_pc_problem;
