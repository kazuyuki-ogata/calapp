-- SQL_ID : 41_12_03
-- ���[�N_�e�L�X�g���_�ꎞ�o�^
-- MML�̃e�L�X�g�f�[�^�𒊏o���A���[�N_�e�L�X�g���_�ꎞ�e�[�u���Ɋi�[����B
WITH merge_mml_pc_external_reference AS ( 
    SELECT
        facility_id
        , master_id
        , uid
        , keika_seq AS module_seq
        , 1 AS problem_seq
        , 1 AS assessment_item_seq
        , gaibu_sansyo_seq
        , 1 AS keika_seq
        , 'pc' AS source_module
        , 'external_refrence' AS source_table
        , 'gaibu_sansyo_naiyo' AS source_column
        , shinryo_ymd AS comfirm_date
        , NULL AS event_date
        , NULL AS history_start_ymd
        , NULL AS history_end_ymd
        , gaibu_sansyo_naiyo AS original_text
        , CASE 
            WHEN gaibu_sansyo_file_name = '�v���O���X�m�[�g(S)' 
                THEN 1 
            ELSE 0 
            END AS chief_complaint_f 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_pc_external_reference 
    WHERE
        -- �O���Q�Ɠ��e��NULL�A�󔒂�����
        COALESCE(gaibu_sansyo_naiyo, '') <> ''
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_text_temp 
SELECT
    merge_mml_pc_external_reference.facility_id
    , merge_mml_pc_external_reference.master_id
    , merge_mml_pc_external_reference.uid
    , merge_mml_pc_external_reference.module_seq
    , merge_mml_pc_external_reference.problem_seq
    , merge_mml_pc_external_reference.assessment_item_seq
    , merge_mml_pc_external_reference.gaibu_sansyo_seq
    , merge_mml_pc_external_reference.keika_seq
    , merge_mml_pc_external_reference.source_module
    , merge_mml_pc_external_reference.source_table
    , merge_mml_pc_external_reference.source_column
    , merge_mml_pc_external_reference.comfirm_date
    , merge_mml_pc_external_reference.event_date
    , merge_mml_pc_external_reference.history_start_ymd
    , merge_mml_pc_external_reference.history_end_ymd
    , merge_mml_pc_external_reference.original_text
    , merge_mml_pc_external_reference.chief_complaint_f 
FROM
    merge_mml_pc_external_reference;
