-- SQL_ID : 41_11
-- ���[�N_���̌����f�[�^�o�^
-- MML�̌��̌����f�[�^�𒊏o���A���[�N_���̌����f�[�^�e�[�u���Ɋi�[����B
WITH kensa AS ( 
    SELECT
        kensa_scm2.facility_id
        , kensa_scm2.himoduke_id
        , kensa_scm2.specimen_name
        , kensa_scm2.sp_code
        , kensa_scm2.item_name
        , kensa_scm2.facility_it_code
        , kensa_scm2.unit
        , 
        LEFT (kensa_scm2.sample_time, 8) ::DATE AS sample_time
        , kensa_scm2.value
        , kensa_scm2.num_value
        , rank() OVER ( 
            PARTITION BY
                kensa_scm2.facility_id
                , kensa_scm2.himoduke_id
                , kensa_scm2.specimen_name
                , kensa_scm2.sp_code
                , kensa_scm2.item_name
                , kensa_scm2.facility_it_code
                , kensa_scm2.unit
                , 
                LEFT (kensa_scm2.sample_time, 8) ::DATE 
            ORDER BY
                kensa_scm2.sample_time DESC
        ) AS row_no 
    FROM
        milscm_2023_010.azn_202310_work_kensa_scm2 AS kensa_scm2 
    WHERE
        kensa_scm2.row_no = 1 
    UNION ALL 
    SELECT
        kensa_scm4.facility_id
        , kensa_scm4.himoduke_id
        , kensa_scm4.specimen_name
        , kensa_scm4.sp_code
        , kensa_scm4.item_name
        , kensa_scm4.facility_it_code
        , kensa_scm4.unit
        , kensa_scm4.sample_time ::DATE
        , kensa_scm4.value
        , kensa_scm4.num_value
        , rank() OVER ( 
            PARTITION BY
                kensa_scm4.facility_id
                , kensa_scm4.himoduke_id
                , kensa_scm4.specimen_name
                , kensa_scm4.sp_code
                , kensa_scm4.item_name
                , kensa_scm4.facility_it_code
                , kensa_scm4.unit
                , kensa_scm4.sample_time ::DATE 
            ORDER BY
                kensa_scm4.sample_time DESC
        ) AS row_no 
    FROM
        milscm_2023_010.azn_202310_work_kensa_scm4 AS kensa_scm4 
    WHERE
        kensa_scm4.row_no = 1
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_kensa 
SELECT
    kensa.facility_id
    , kensa.himoduke_id
    , kensa.specimen_name
    , kensa.sp_code
    , kensa.item_name
    , kensa.facility_it_code
    , kensa.unit
    , kensa.sample_time
    , kensa.value
    , kensa.num_value
    , kensa.row_no 
FROM
    kensa;
