-- SQL_ID : 41_12_12
-- ���[�N_�e�L�X�g���_�ꎞ�o�^
-- MML�̃e�L�X�g�f�[�^�𒊏o���A���[�N_�e�L�X�g���_�ꎞ�e�[�u���Ɋi�[����B
WITH merge_mml_sm_summary AS ( 
    SELECT
        facility_id
        , master_id
        , uid
        , summary_seq AS module_seq
        , 1 AS problem_seq
        , 1 AS assessment_item_seq
        , 1 AS gaibu_sansyo_seq
        , 1 AS keika_seq
        , 'sm' AS source_module
        , 'summary' AS source_table
        , 'taiin_findings' AS source_column
        , shinryo_ymd AS comfirm_date
        , NULL AS event_date
        , history_start_ymd
        , history_end_ymd
        , taiin_findings AS original_text
        , 0 AS chief_complaint_f 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_sm_summary 
    WHERE
        -- �މ@��������NULL�A�󔒂�����
        COALESCE(taiin_findings, '') <> ''
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_text_temp 
SELECT
    merge_mml_sm_summary.facility_id
    , merge_mml_sm_summary.master_id
    , merge_mml_sm_summary.uid
    , merge_mml_sm_summary.module_seq
    , merge_mml_sm_summary.problem_seq
    , merge_mml_sm_summary.assessment_item_seq
    , merge_mml_sm_summary.gaibu_sansyo_seq
    , merge_mml_sm_summary.keika_seq
    , merge_mml_sm_summary.source_module
    , merge_mml_sm_summary.source_table
    , merge_mml_sm_summary.source_column
    , merge_mml_sm_summary.comfirm_date
    , merge_mml_sm_summary.event_date
    , merge_mml_sm_summary.history_start_ymd
    , merge_mml_sm_summary.history_end_ymd
    , merge_mml_sm_summary.original_text
    , merge_mml_sm_summary.chief_complaint_f 
FROM
    merge_mml_sm_summary;
