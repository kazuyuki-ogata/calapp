-- SQL_ID : 11_02
-- �g����_�Ώێ����o�^
-- MML�f�f������񂩂�g��������̎�������o�^����B

INSERT 
INTO milscm_2023_010.azn_202310_enroll_shikkan 
SELECT DISTINCT
    union_mmlrd.* 
FROM
    ( 
        SELECT
            facility_id
            , master_id
            , byomei
            , byomei_code 
        FROM
            milscm_2023_010.azn_202310_backup_merge_mml_rd_byomei 
        UNION ALL 
        SELECT
            v_shisetsu.facility_id
            , mmlrd.master_id
            , mmlrd.byomei
            , mmlrd.byomei_code 
        FROM
            ( 
                SELECT
                    facility_id_mml
                    , master_id
                    , diagnosis AS byomei
                    , code AS byomei_code 
                FROM
                    milscm_2023_010.azn_202310_backup_text_mml_mmlrd_byomei 
            ) AS mmlrd 
            INNER JOIN milscm4.v_latest_shisetsu_info_system AS v_shisetsu 
                ON mmlrd.facility_id_mml = v_shisetsu.facility_id_mml
    ) union_mmlrd;
