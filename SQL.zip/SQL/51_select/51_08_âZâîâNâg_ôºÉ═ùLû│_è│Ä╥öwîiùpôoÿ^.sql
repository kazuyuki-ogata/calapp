-- SQL_ID : 51_08
-- �Z���N�g_���͗L��_���Ҕw�i�p�o�^
-- �Z���N�g_���҃f�[�^����w������̂��̂��A�Z���N�g_���͗L��_���Ҕw�i�p�e�[�u���Ɋi�[����B
WITH hd AS ( 
    SELECT
        shinryou_koui.facility_id
        , shinryou_koui.himoduke_id
        , sum( 
            CASE 
                WHEN shinryou_koui.jisshi_ymd ::DATE >= temp_kanja.shoho_start_date ::DATE 
                AND shinryou_koui.jisshi_ymd ::DATE <= temp_kanja.shoho_end_date ::DATE 
                    THEN 1 
                ELSE NULL 
                END
        ) AS HD_time 
    FROM
        milscm_2023_010.azn_202310_work_shinryou_koui AS shinryou_koui 
        LEFT JOIN milscm_2023_010.azn_202310_select_patient_basic AS temp_kanja 
            ON shinryou_koui.facility_id = temp_kanja.facility_id 
            AND shinryou_koui.himoduke_id = temp_kanja.himoduke_id 
    GROUP BY
        shinryou_koui.facility_id
        , shinryou_koui.himoduke_id
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_kanja_backborn_hd 
SELECT
    kanja.facility_id
    , kanja.himoduke_id
    , CASE 
        WHEN hd.HD_time >= 1 
            THEN 1 
        ELSE NULL 
        END AS hd_flg 
FROM
    milscm_2023_010.azn_202310_select_patient_basic AS kanja 
    LEFT JOIN hd 
        ON ( 
            kanja.facility_id = hd.facility_id 
            AND kanja.himoduke_id = hd.himoduke_id
        );
