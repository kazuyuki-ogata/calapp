-- SQL_ID : 51_09
-- �Z���N�g_�o�C�^���o�^
-- �Z���N�g_���҃f�[�^����w������̂��̂��A�Z���N�g_�o�C�^���e�[�u���Ɋi�[����B
WITH vital AS ( 
    SELECT
        work_vital.facility_id
        , work_vital.himoduke_id
        , work_vital.item_name
        , work_vital.vital_sign_num_value
        , rank() OVER ( 
            PARTITION BY
                work_vital.facility_id
                , work_vital.himoduke_id
                , work_vital.item_name 
            ORDER BY
                abs( 
                    work_vital.vital_sign_date ::DATE - kanja.index_date ::DATE
                )
        ) AS date_rank 
    FROM
        milscm_2023_010.azn_202310_work_vital AS work_vital 
        INNER JOIN ( 
            SELECT
                facility_id
                , himoduke_id
                , index_date 
            FROM
                milscm_2023_010.azn_202310_select_patient_basic
        ) AS kanja 
            ON ( 
                work_vital.facility_id = kanja.facility_id 
                AND work_vital.himoduke_id = kanja.himoduke_id
            )
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_vital 
SELECT
    vital.item_name
    , vital.facility_id
    , vital.himoduke_id
    , avg(vital.vital_sign_num_value ::NUMERIC) AS vital_sign_num_value 
FROM
    vital 
WHERE
    vital.date_rank = 1 
GROUP BY
    vital.item_name
    , vital.facility_id
    , vital.himoduke_id;
