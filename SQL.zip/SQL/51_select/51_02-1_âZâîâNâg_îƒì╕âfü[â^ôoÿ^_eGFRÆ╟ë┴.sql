-- SQL_ID : 51_02-1
-- セレクト_検査データ登録_eGFR追加
-- セレクト_検査データから表示名が血清クレアチニンのデータを抽出し、eGFRを算出した結果をセレクト_検査データテーブルに格納する。
WITH kensa AS ( 
    SELECT
        facility_id
        , himoduke_id
        , num_value
        , sample_time 
    FROM
        milscm_2023_010.azn_202310_select_kensa 
    WHERE
        disp_name = '血清クレアチニン'
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_kensa 
SELECT
    kensa.facility_id
    , kensa.himoduke_id
    , CASE 
        WHEN kanja.sex_kubun = '1' 
            THEN 194 * power(kensa.num_value, - 1.094) * power(kanja.age ::NUMERIC, - 0.287) 
        ELSE 194 * power(kensa.num_value, - 1.094) * power(kanja.age ::NUMERIC, - 0.287) * 0.739 
        END AS num_value
    , kensa.sample_time
    , 'eGFR' AS disp_name 
FROM
    kensa 
    INNER JOIN milscm_2023_010.azn_202310_select_patient_basic AS kanja 
        ON ( 
            kanja.age ::INTEGER >= 18 
            AND kensa.facility_id = kanja.facility_id 
            AND kensa.himoduke_id = kanja.himoduke_id
        );
