-- SQL_ID : 51_05
-- セレクト_併用薬データ_患者背景用登録
-- セレクト_患者データから指定表示名のものをフラグ設定し、セレクト_併用薬データ_患者背景用テーブルに格納する。
WITH med AS ( 
    SELECT
        shohou.disp_name
        , shohou.facility_id
        , shohou.himoduke_id
        , sum( 
            CASE 
                WHEN shohou.jisshi_ymd ::DATE >= kanja.shoho_start_date ::DATE 
                AND shohou.jisshi_ymd ::DATE <= kanja.shoho_end_date ::DATE 
                    THEN 1 
                ELSE NULL 
                END
        ) AS med_time 
    FROM
        milscm_2023_010.azn_202310_work_shohou AS shohou 
        LEFT JOIN milscm_2023_010.azn_202310_select_patient_basic AS kanja 
            ON shohou.facility_id = kanja.facility_id 
            AND shohou.himoduke_id = kanja.himoduke_id 
    GROUP BY
        shohou.disp_name
        , shohou.facility_id
        , shohou.himoduke_id
) 
, med2 AS ( 
    SELECT
        med.facility_id
        , med.himoduke_id
        , MAX( 
            CASE 
                WHEN med.disp_name = '利尿薬' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c01
        , MAX( 
            CASE 
                WHEN med.disp_name = 'βブロッカー' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c02
        , MAX( 
            CASE 
                WHEN med.disp_name = 'スピロノラクトン' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c03
        , MAX( 
            CASE 
                WHEN med.disp_name = 'エプレレノン' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c04
        , MAX( 
            CASE 
                WHEN med.disp_name = 'エサキセレノン' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c05
        , MAX( 
            CASE 
                WHEN med.disp_name = 'フィネレノン' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c06
        , MAX( 
            CASE 
                WHEN med.disp_name = 'ACE' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c07
        , MAX( 
            CASE 
                WHEN med.disp_name = 'ARB' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c08
        , MAX( 
            CASE 
                WHEN med.disp_name = 'ARNI' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c09
        , MAX( 
            CASE 
                WHEN med.disp_name = 'SGLT-2阻害薬（フォシーガ）' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c10
        , MAX( 
            CASE 
                WHEN med.disp_name = 'SGLT-2阻害薬（フォシーガ以外）' 
                AND med.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS c11 
    FROM
        med 
    GROUP BY
        med.facility_id
        , med.himoduke_id
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_kanja_backborn_yakuzai 
SELECT
    kanja.facility_id
    , kanja.himoduke_id
    , CASE 
        WHEN med2.c01 IS NULL 
            THEN 0 
        ELSE med2.c01 
        END AS c01
    , CASE 
        WHEN med2.c02 IS NULL 
            THEN 0 
        ELSE med2.c02 
        END AS c02
    , CASE 
        WHEN med2.c03 IS NULL 
            THEN 0 
        ELSE med2.c03 
        END AS c03
    , CASE 
        WHEN med2.c04 IS NULL 
            THEN 0 
        ELSE med2.c04 
        END AS c04
    , CASE 
        WHEN med2.c05 IS NULL 
            THEN 0 
        ELSE med2.c05 
        END AS c05
    , CASE 
        WHEN med2.c06 IS NULL 
            THEN 0 
        ELSE med2.c06 
        END AS c06
    , CASE 
        WHEN med2.c07 IS NULL 
            THEN 0 
        ELSE med2.c07 
        END AS c07
    , CASE 
        WHEN med2.c08 IS NULL 
            THEN 0 
        ELSE med2.c08 
        END AS c08
    , CASE 
        WHEN med2.c09 IS NULL 
            THEN 0 
        ELSE med2.c09 
        END AS c09
    , CASE 
        WHEN med2.c10 IS NULL 
            THEN 0 
        ELSE med2.c10 
        END AS c10
    , CASE 
        WHEN med2.c11 IS NULL 
            THEN 0 
        ELSE med2.c11 
        END AS c11 
FROM
    milscm_2023_010.azn_202310_select_patient_basic AS kanja 
    LEFT JOIN med2 
        ON ( 
            kanja.facility_id = med2.facility_id 
            AND kanja.himoduke_id = med2.himoduke_id
        );
