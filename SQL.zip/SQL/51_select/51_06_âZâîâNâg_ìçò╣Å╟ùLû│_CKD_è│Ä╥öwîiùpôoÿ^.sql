-- SQL_ID : 51_06
-- �Z���N�g_�����ǗL��_kensa_���Ҕw�i�p�o�^
-- �Z���N�g_���҃f�[�^����w������̂��̂��A�Z���N�g_�����ǗL��_kensa_���Ҕw�i�p�e�[�u���Ɋi�[����B
WITH temp_kensa AS ( 
    SELECT DISTINCT
        facility_id
        , himoduke_id
        , sample_time AS shinryo_start_date 
    FROM
        milscm_2023_010.azn_202310_select_kanja_backborn_kensa 
    WHERE
        disp_name = 'eGFR' 
        AND num_value ::INTEGER < 60
) 
, kensa AS ( 
    SELECT
        temp_kensa.facility_id
        , temp_kensa.himoduke_id
        , sum( 
            CASE 
                WHEN temp_kensa.shinryo_start_date ::DATE >= temp_kanja.shoho_start_date ::DATE 
                AND temp_kensa.shinryo_start_date ::DATE <= temp_kanja.shoho_end_date ::DATE 
                    THEN 1 
                ELSE NULL 
                END
        ) AS kensa_time 
    FROM
        temp_kensa 
        LEFT JOIN milscm_2023_010.azn_202310_select_patient_basic AS temp_kanja 
            ON temp_kensa.facility_id = temp_kanja.facility_id 
            AND temp_kensa.himoduke_id = temp_kanja.himoduke_id 
    GROUP BY
        temp_kensa.facility_id
        , temp_kensa.himoduke_id
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_kanja_backborn_gappei01 
SELECT
    kanja.facility_id
    , kanja.himoduke_id
    , CASE 
        WHEN kensa.kensa_time >= 1 
            THEN 1 
        ELSE 0 
        END AS d01 
FROM
    milscm_2023_010.azn_202310_select_patient_basic AS kanja 
    LEFT JOIN kensa 
        ON ( 
            kanja.facility_id = kensa.facility_id 
            AND kanja.himoduke_id = kensa.himoduke_id
        );
