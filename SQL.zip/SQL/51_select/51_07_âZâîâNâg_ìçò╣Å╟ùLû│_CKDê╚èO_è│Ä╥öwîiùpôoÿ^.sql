-- SQL_ID : 51_07
-- セレクト_合併症有無_CKD以外_患者背景用登録
-- セレクト_患者データから指定条件のものを、セレクト_合併症有無_CKD以外_患者背景用テーブルに格納する。
WITH shikkan AS ( 
    SELECT
        temp_shikkan.disp_name
        , temp_shikkan.facility_id
        , temp_shikkan.himoduke_id
        , sum( 
            CASE 
                WHEN ( 
                    substr(temp_shikkan.shinryo_start_date, 1, 6) || '01'
                ) ::DATE >= temp_kanja.shoho_start_date ::DATE 
                AND ( 
                    substr(temp_shikkan.shinryo_start_date, 1, 6) || '01'
                ) ::DATE <= temp_kanja.shoho_end_date ::DATE 
                    THEN 1 
                ELSE NULL 
                END
        ) AS med_time 
    FROM
        milscm_2023_010.azn_202310_work_shikkan_dpc AS temp_shikkan 
        LEFT JOIN milscm_2023_010.azn_202310_select_patient_basic AS temp_kanja 
            ON ( 
                temp_shikkan.facility_id = temp_kanja.facility_id 
                AND temp_shikkan.himoduke_id = temp_kanja.himoduke_id
            ) 
    GROUP BY
        temp_shikkan.disp_name
        , temp_shikkan.facility_id
        , temp_shikkan.himoduke_id
) 
, shikkan_list AS ( 
    SELECT
        shikkan.facility_id
        , shikkan.himoduke_id
        , max( 
            CASE 
                WHEN shikkan.disp_name = '慢性心不全' 
                AND shikkan.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS d02
        , max( 
            CASE 
                WHEN shikkan.disp_name = '糖尿病' 
                AND shikkan.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS d03
        , max( 
            CASE 
                WHEN shikkan.disp_name = '高血圧' 
                AND shikkan.med_time >= 1 
                    THEN 1 
                ELSE 0 
                END
        ) AS d04 
    FROM
        shikkan 
    GROUP BY
        shikkan.facility_id
        , shikkan.himoduke_id
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_kanja_backborn_gappei02 
SELECT
    kanja.facility_id
    , kanja.himoduke_id
    , CASE 
        WHEN shikkan_list.d02 IS NULL 
            THEN 0 
        ELSE shikkan_list.d02 
        END AS d02
    , CASE 
        WHEN shikkan_list.d03 IS NULL 
            THEN 0 
        ELSE shikkan_list.d03 
        END AS d03
    , CASE 
        WHEN shikkan_list.d04 IS NULL 
            THEN 0 
        ELSE shikkan_list.d04 
        END AS d04 
FROM
    milscm_2023_010.azn_202310_select_patient_basic AS kanja 
    LEFT JOIN shikkan_list 
        ON ( 
            kanja.facility_id = shikkan_list.facility_id 
            AND kanja.himoduke_id = shikkan_list.himoduke_id
        );
