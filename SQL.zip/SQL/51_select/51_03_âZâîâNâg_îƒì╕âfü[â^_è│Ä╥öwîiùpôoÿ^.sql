-- SQL_ID : 51_03
-- �Z���N�g_�����f�[�^_���Ҕw�i�p�o�^
-- �Z���N�g_�����f�[�^����w����Ԃ̂��̂��A�Z���N�g_�����f�[�^_���Ҕw�i�p�e�[�u���Ɋi�[����B
WITH temp_list AS ( 
    SELECT
        kensa.facility_id
        , kensa.himoduke_id
        , avg(kensa.num_value) AS num_value
        , kensa.sample_time
        , kensa.disp_name
        , max(kanja.index_date) ::DATE - kensa.sample_time ::DATE AS days 
    FROM
        milscm_2023_010.azn_202310_select_kensa AS kensa 
        INNER JOIN milscm_2023_010.azn_202310_select_patient_basic AS kanja 
            ON ( 
                kensa.sample_time ::DATE BETWEEN ( 
                    (kanja.index_date ::DATE) + 1 - kanja.look_back_term
                ) AND kanja.index_date ::DATE 
                AND kensa.facility_id = kanja.facility_id 
                AND kensa.himoduke_id = kanja.himoduke_id
            ) 
    GROUP BY
        kensa.facility_id
        , kensa.himoduke_id
        , kensa.disp_name
        , kensa.sample_time
) 
, select_list AS ( 
    SELECT
        temp_list.facility_id
        , temp_list.himoduke_id
        , temp_list.sample_time
        , temp_list.disp_name
        , temp_list.num_value
        , row_number() OVER ( 
            PARTITION BY
                temp_list.facility_id
                , temp_list.himoduke_id
                , temp_list.disp_name 
            ORDER BY
                temp_list.days
        ) AS row_no 
    FROM
        temp_list
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_kanja_backborn_kensa 
SELECT
    select_list.facility_id
    , select_list.himoduke_id
    , select_list.sample_time
    , select_list.disp_name
    , select_list.num_value 
FROM
    select_list 
WHERE
    select_list.row_no = 1;
