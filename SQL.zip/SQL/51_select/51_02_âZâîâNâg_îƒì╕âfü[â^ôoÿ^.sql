-- SQL_ID : 51_02
-- �Z���N�g_�����f�[�^�o�^
-- MML�̃e�L�X�g�f�[�^�𒊏o���A�Z���N�g_�����f�[�^�e�[�u���Ɋi�[����B
WITH kensa_join AS ( 
    SELECT
        mml_lb.facility_id
        , mml_lb.himoduke_id
        , mml_lb.num_value ::NUMERIC
        , mml_lb.sample_time
        , mt_kensa.disp_name 
    FROM
        milscm_2023_010.azn_202310_work_kensa AS mml_lb 
        INNER JOIN milscm_2023_010.azn_202310_mt_kensa AS mt_kensa 
            ON ( 
                mml_lb.facility_id = mt_kensa.facility_id 
                AND mml_lb.specimen_name = mt_kensa.specimen_name 
                AND mml_lb.sp_code = mt_kensa.sp_code 
                AND mml_lb.item_name = mt_kensa.item_name 
                AND mml_lb.facility_it_code = mt_kensa.item_code
            ) 
    WHERE
        mml_lb.num_value <> ''
) 
INSERT 
INTO milscm_2023_010.azn_202310_select_kensa 
SELECT
    kensa_join.facility_id
    , kensa_join.himoduke_id
    , kensa_join.num_value
    , kensa_join.sample_time
    , kensa_join.disp_name 
FROM
    kensa_join;
