--DROP TABLE  milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei;
CREATE TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei( 
    zip_no INTEGER NOT NULL                     -- Zip�t�@�C��No
    , file_no INTEGER NOT NULL                  -- �t�@�C��No
    , body_no INTEGER NOT NULL                  -- �{��No
    , facility_id_mml TEXT NOT NULL             -- �{��ID�iMML�j
    , master_id TEXT NOT NULL                   -- ����ID
    , surgery_item_no INTEGER NOT NULL          -- ��p����No
    , rd_no INTEGER NOT NULL                    -- �f�f�������No
    , byomei_no INTEGER NOT NULL                -- �a��No
    , tag_name TEXT                             -- �^�O��
    , diagnosis TEXT                            -- �a��
    , code TEXT                                 -- �R�[�h�l
    , system TEXT                               -- �R�[�h�̌n��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei ADD CONSTRAINT azn_202310_backup_text_mml_mmlsg_rd_byomei_pkey
 PRIMARY KEY ( 
    zip_no
    , file_no
    , body_no
    , surgery_item_no
    , rd_no
    , byomei_no
); 

ALTER TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei IS '�o�b�N�A�b�v_MML_��p���W���[��_�a��'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.zip_no IS 'Zip�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.file_no IS '�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.body_no IS '�{��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.facility_id_mml IS '�{��ID�iMML�j'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.master_id IS '����ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.surgery_item_no IS '��p����No'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.rd_no IS '�f�f�������No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.byomei_no IS '�a��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.tag_name IS '�^�O��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.diagnosis IS '�a��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.code IS '�R�[�h�l'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlsg_rd_byomei.system IS '�R�[�h�̌n��';
