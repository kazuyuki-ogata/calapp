--DROP TABLE  milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke;
CREATE TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , data_type TEXT NOT NULL                   -- �f�[�^���
    , patient_id TEXT NOT NULL                  -- ����ID
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke ADD CONSTRAINT azn_202310_backup_mart_2riyo_patient_himoduke_pkey
 PRIMARY KEY (facility_id, himoduke_id, data_type, patient_id); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke IS '�o�b�N�A�b�v_�񎟗��pDB�o�^���ҕR�t���f�[�^'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke.data_type IS '�f�[�^���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_himoduke.patient_id IS '����ID';
