--DROP TABLE  milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine;
CREATE TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine( 
    zip_no INTEGER NOT NULL                     -- Zip�t�@�C��No
    , file_no INTEGER NOT NULL                  -- �t�@�C��No
    , body_no INTEGER NOT NULL                  -- �{��No
    , facility_id_mml TEXT NOT NULL             -- �{��ID�iMML�j
    , master_id TEXT NOT NULL                   -- ����ID
    , medication_no INTEGER NOT NULL            -- ����No
    , medicine_no INTEGER NOT NULL              -- ���No
    , code TEXT                                 -- ��܃R�[�h
    , system TEXT                               -- ��܃R�[�h�̌n
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine ADD CONSTRAINT azn_202310_backup_text_mml_mmlinj_medicine_pkey
 PRIMARY KEY ( 
    zip_no
    , file_no
    , body_no
    , medication_no
    , medicine_no
); 

ALTER TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine IS '�o�b�N�A�b�v_MML_���ˋL�^���W���[��_���'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.zip_no IS 'Zip�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.file_no IS '�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.body_no IS '�{��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.facility_id_mml IS '�{��ID�iMML�j'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.master_id IS '����ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.medication_no IS '����No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.medicine_no IS '���No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.code IS '��܃R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlinj_medicine.system IS '��܃R�[�h�̌n';
