--DROP TABLE  milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei;
CREATE TABLE milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei( 
    zip_no INTEGER NOT NULL                     -- Zip�t�@�C��No
    , file_no INTEGER NOT NULL                  -- �t�@�C��No
    , body_no INTEGER NOT NULL                  -- �{��No
    , facility_id_mml TEXT NOT NULL             -- �{��ID�iMML�j
    , master_id TEXT NOT NULL                   -- ����ID
    , byomei_no INTEGER NOT NULL                -- �a��No
    , tag_name TEXT                             -- �^�O��
    , diagnosis TEXT                            -- �a��
    , code TEXT                                 -- �R�[�h�l
    , system TEXT                               -- �R�[�h�̌n��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei ADD CONSTRAINT azn_202310_base_text_mml_mmlrd_byomei_pkey
 PRIMARY KEY (zip_no, file_no, body_no, byomei_no); 

ALTER TABLE milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei IS '�x�[�X_MML_�f�f������񃂃W���[��_�a��'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.zip_no IS 'Zip�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.file_no IS '�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.body_no IS '�{��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.facility_id_mml IS '�{��ID�iMML�j'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.master_id IS '����ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.byomei_no IS '�a��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.tag_name IS '�^�O��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.diagnosis IS '�a��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.code IS '�R�[�h�l'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_base_text_mml_mmlrd_byomei.system IS '�R�[�h�̌n��';
