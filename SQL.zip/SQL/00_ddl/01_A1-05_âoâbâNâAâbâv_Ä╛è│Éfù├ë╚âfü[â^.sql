--DROP TABLE  milscm_2023_010.azn_202310_backup_mart_shikkan_department;
CREATE TABLE milscm_2023_010.azn_202310_backup_mart_shikkan_department( 
    parent_seq_no INTEGER NOT NULL              -- �e�V�[�P���X�ԍ�
    , department_name TEXT                      -- �f�ÉȖ�
    , department_kubun TEXT                     -- �f�ÉȖ��敪
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mart_shikkan_department ADD CONSTRAINT azn_202310_backup_mart_shikkan_department_pkey
 PRIMARY KEY (parent_seq_no, department_kubun); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mart_shikkan_department OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mart_shikkan_department IS '�o�b�N�A�b�v_�����f�Éȃf�[�^'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_shikkan_department.parent_seq_no IS '�e�V�[�P���X�ԍ�'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_shikkan_department.department_name IS '�f�ÉȖ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_shikkan_department.department_kubun IS '�f�ÉȖ��敪'
;
