--DROP TABLE  milscm_2023_010.azn_202310_work_look_back;
CREATE TABLE milscm_2023_010.azn_202310_work_look_back( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , min_jisshi_ymd TEXT NOT NULL              -- ���{��(�ŏ�)
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_work_look_back ADD CONSTRAINT azn_202310_work_look_back_pkey
 PRIMARY KEY (facility_id, himoduke_id, min_jisshi_ymd); 

ALTER TABLE milscm_2023_010.azn_202310_work_look_back OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_work_look_back IS '���[�N_look_back'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_look_back.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_look_back.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_look_back.min_jisshi_ymd IS '���{��(�ŏ�)';
