--DROP TABLE  milscm_2023_010.azn_202310_select_kensa_k;
CREATE TABLE milscm_2023_010.azn_202310_select_kensa_k( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , sample_time TEXT NOT NULL                 -- �̎����
    , index_date TEXT NOT NULL                  -- index_date
    , num_value NUMERIC NOT NULL                -- ���l����
    , days TEXT NOT NULL                        -- �o�ߓ�
    , weeks INTEGER NOT NULL                    -- �o�ߏT
    , months INTEGER NOT NULL                   -- �o�ߌ�
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_select_kensa_k ADD CONSTRAINT azn_202310_select_kensa_k_pkey
 PRIMARY KEY (facility_id, himoduke_id, sample_time); 

ALTER TABLE milscm_2023_010.azn_202310_select_kensa_k OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_select_kensa_k IS '�Z���N�g_�����f�[�^_�J���E��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.sample_time IS '�̎����'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.index_date IS 'index_date'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.num_value IS '���l����'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.days IS '�o�ߓ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.weeks IS '�o�ߏT'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa_k.months IS '�o�ߌ�';
