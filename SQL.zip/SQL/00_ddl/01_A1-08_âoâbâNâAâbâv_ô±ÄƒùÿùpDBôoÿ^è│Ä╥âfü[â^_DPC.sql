--DROP TABLE  milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc;
CREATE TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc( 
    mil_karute_id INTEGER NOT NULL              -- ��N�J���eID
    , facility_id TEXT NOT NULL                 -- �{��ID
    , patient_id TEXT NOT NULL                  -- ����ID
    , shinryo_ym_min TEXT NOT NULL              -- �f�ÔN��_�ŏ�
    , shinryo_ym_max TEXT NOT NULL              -- �f�ÔN��_�ő�
    , sex_kubun TEXT NOT NULL                   -- �j���敪
    , birthday TEXT NOT NULL                    -- ���N����
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc ADD CONSTRAINT azn_202310_backup_mart_2riyo_patient_id_dpc_pkey
 PRIMARY KEY ( 
    mil_karute_id
    , facility_id
    , patient_id
    , sex_kubun
    , birthday
); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc IS '�o�b�N�A�b�v_�񎟗��pDB�o�^���҃f�[�^_DPC'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc.mil_karute_id IS '��N�J���eID'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc.patient_id IS '����ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc.shinryo_ym_min IS '�f�ÔN��_�ŏ�'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc.shinryo_ym_max IS '�f�ÔN��_�ő�'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc.sex_kubun IS '�j���敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id_dpc.birthday IS '���N����';
