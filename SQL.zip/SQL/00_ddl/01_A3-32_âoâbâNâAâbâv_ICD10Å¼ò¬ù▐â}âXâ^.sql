--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_icd10_s;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_icd10_s( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , koshin_kubun TEXT NOT NULL                -- �X�V�敪
    , icd10_s_code TEXT NOT NULL                -- ICD10�����ރR�[�h
    , icd10_s_name TEXT NOT NULL                -- ICD10�����ޖ�
    , icd10_l_code TEXT NOT NULL                -- ICD10�啪�ރR�[�h
    , icd10_m_code TEXT NOT NULL                -- ICD10�����ރR�[�h
    , ikosaki TEXT                              -- �ڍs��
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_icd10_s ADD CONSTRAINT azn_202310_backup_mt_icd10_s_pkey
 PRIMARY KEY (sekoubi, koshin_kubun, icd10_s_code); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_icd10_s OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_icd10_s IS '�o�b�N�A�b�v_ICD10�����ރ}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.koshin_kubun IS '�X�V�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.icd10_s_code IS 'ICD10�����ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.icd10_s_name IS 'ICD10�����ޖ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.icd10_l_code IS 'ICD10�啪�ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.icd10_m_code IS 'ICD10�����ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.ikosaki IS '�ڍs��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_s.update_ymd IS '�f�[�^�o�^��';
