--DROP TABLE  milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj;
CREATE TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj( 
    zip_no INTEGER NOT NULL                     -- Zip�t�@�C��No
    , file_no INTEGER NOT NULL                  -- �t�@�C��No
    , body_no INTEGER NOT NULL                  -- �{��No
    , facility_id_mml TEXT NOT NULL             -- �{��ID�iMML�j
    , master_id TEXT NOT NULL                   -- ����ID
    , narcotic_prescription_license_no TEXT     -- ����{�p�Ҕԍ�
    , COMMENT TEXT                              -- �R�����g
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj ADD CONSTRAINT azn_202310_backup_text_mml_mmlre_inj_pkey
 PRIMARY KEY (zip_no, file_no, body_no); 

ALTER TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj IS '�o�b�N�A�b�v_MML_�Љ�󃂃W���[��_���ˋL�^'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj.zip_no IS 'Zip�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj.file_no IS '�t�@�C��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj.body_no IS '�{��No'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj.facility_id_mml IS '�{��ID�iMML�j'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj.master_id IS '����ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj.narcotic_prescription_license_no IS
     '����{�p�Ҕԍ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_text_mml_mmlre_inj.COMMENT IS '�R�����g';
