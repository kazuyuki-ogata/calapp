--DROP TABLE  milscm_2023_010.azn_202310_mt_kanja;
CREATE TABLE milscm_2023_010.azn_202310_mt_kanja( 
    mask_id TEXT NOT NULL                       -- �}�X�NID
    , facility_id TEXT NOT NULL                 -- �{��ID
    , facility_id_mml TEXT                      -- �{��ID�iMML�j
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_mt_kanja ADD CONSTRAINT azn_202310_mt_kanja_pkey PRIMARY
 KEY (mask_id); 

ALTER TABLE milscm_2023_010.azn_202310_mt_kanja OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_mt_kanja IS '���҃}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_kanja.mask_id IS '�}�X�NID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_kanja.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_kanja.facility_id_mml IS '�{��ID�iMML�j'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_kanja.himoduke_id IS '�R�t��ID';
