--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_tokutei_kizai;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_tokutei_kizai( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , koshin_kubun TEXT NOT NULL                -- �X�V�敪
    , tokutei_kizai_cd TEXT NOT NULL            -- �����ރR�[�h
    , tokutei_kizai_name TEXT NOT NULL          -- �����ޖ��E�K�i��
    , tokutei_kizai_tani TEXT                   -- �P��
    , tokutei_kizai_kingaku NUMERIC NOT NULL    -- ���z
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_tokutei_kizai ADD CONSTRAINT azn_202310_backup_mt_tokutei_kizai_pkey
 PRIMARY KEY (sekoubi, koshin_kubun, tokutei_kizai_cd); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_tokutei_kizai OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_tokutei_kizai IS '�o�b�N�A�b�v_����@�ރ}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.koshin_kubun IS '�X�V�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.tokutei_kizai_cd IS '�����ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.tokutei_kizai_name IS '�����ޖ��E�K�i��'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.tokutei_kizai_tani IS '�P��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.tokutei_kizai_kingaku IS '���z'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_tokutei_kizai.update_ymd IS '�f�[�^�o�^��';
