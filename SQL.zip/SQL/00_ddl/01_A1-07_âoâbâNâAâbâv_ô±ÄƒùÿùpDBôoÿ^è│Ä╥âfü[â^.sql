--DROP TABLE  milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id;
CREATE TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , data_type TEXT NOT NULL                   -- �f�[�^���
    , patient_id TEXT NOT NULL                  -- ����ID
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id ADD CONSTRAINT azn_202310_backup_mart_2riyo_patient_id_pkey
 PRIMARY KEY (facility_id, data_type, patient_id); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id IS '�o�b�N�A�b�v_�񎟗��pDB�o�^���҃f�[�^'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id.data_type IS '�f�[�^���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_2riyo_patient_id.patient_id IS '����ID';
