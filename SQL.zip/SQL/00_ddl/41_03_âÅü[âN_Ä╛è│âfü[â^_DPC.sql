--DROP TABLE  milscm_2023_010.azn_202310_work_shikkan_dpc;
CREATE TABLE milscm_2023_010.azn_202310_work_shikkan_dpc( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , shobyo_code TEXT NOT NULL                 -- ���a���R�[�h
    , shinryo_start_date TEXT NOT NULL          -- �f�ÊJ�n��
    , disp_name TEXT NOT NULL                   -- �\����
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_work_shikkan_dpc ADD CONSTRAINT azn_202310_work_shikkan_dpc_pkey
 PRIMARY KEY (facility_id, himoduke_id); 

ALTER TABLE milscm_2023_010.azn_202310_work_shikkan_dpc OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_work_shikkan_dpc IS '���[�N_�����f�[�^_DPC'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_shikkan_dpc.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_shikkan_dpc.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_shikkan_dpc.shobyo_code IS '���a���R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_shikkan_dpc.shinryo_start_date IS '�f�ÊJ�n��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_shikkan_dpc.disp_name IS '�\����';
