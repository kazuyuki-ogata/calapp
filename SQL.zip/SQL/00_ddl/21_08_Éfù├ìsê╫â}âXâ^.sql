--DROP TABLE  milscm_2023_010.azn_202310_mt_shinryo_koi;
CREATE TABLE milscm_2023_010.azn_202310_mt_shinryo_koi( 
    shinryo_koi_cd TEXT NOT NULL                -- �f�Ís�׃R�[�h
    , cd_no_kubun TEXT NOT NULL                 -- �敪�ԍ�
    , shinryo_koi_name TEXT NOT NULL            -- �f�Ís�׏ȗ���
    , shinryo_koi_kihonname TEXT NOT NULL       -- �f�Ís�ז�
    , disp_name TEXT NOT NULL                   -- �\����
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_mt_shinryo_koi ADD CONSTRAINT azn_202310_mt_shinryo_koi_pkey
 PRIMARY KEY (shinryo_koi_cd); 

ALTER TABLE milscm_2023_010.azn_202310_mt_shinryo_koi OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_mt_shinryo_koi IS '�f�Ís�׃}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shinryo_koi.shinryo_koi_cd IS '�f�Ís�׃R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shinryo_koi.cd_no_kubun IS '�敪�ԍ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shinryo_koi.shinryo_koi_name IS '�f�Ís�׏ȗ���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shinryo_koi.shinryo_koi_kihonname IS '�f�Ís�ז�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shinryo_koi.disp_name IS '�\����';
