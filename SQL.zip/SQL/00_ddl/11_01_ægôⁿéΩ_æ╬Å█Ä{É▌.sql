--DROP TABLE  milscm_2023_010.azn_202310_enroll_shisetsu;
CREATE TABLE milscm_2023_010.azn_202310_enroll_shisetsu( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , facility_id_mml TEXT                      -- �{��ID�iMML�j
    , facility_name TEXT NOT NULL               -- �{�ݖ�
    , facility_contract_start TEXT              -- �{�݃f�[�^�񋟊J�n��
    , facility_contract_end TEXT                -- �{�݃f�[�^�񋟏I����
    , SIZE INTEGER                              -- �{�݋K��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_enroll_shisetsu ADD CONSTRAINT azn_202310_enroll_shisetsu_pkey
 PRIMARY KEY (facility_id); 

ALTER TABLE milscm_2023_010.azn_202310_enroll_shisetsu OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_enroll_shisetsu IS '�g����_�Ώێ{��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shisetsu.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shisetsu.facility_id_mml IS '�{��ID�iMML�j'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shisetsu.facility_name IS '�{�ݖ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shisetsu.facility_contract_start IS '�{�݃f�[�^�񋟊J�n��'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shisetsu.facility_contract_end IS '�{�݃f�[�^�񋟏I����'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shisetsu.SIZE IS '�{�݋K��';
