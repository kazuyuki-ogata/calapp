--DROP TABLE  milscm_2023_010.azn_202310_select_kanja_backborn_hd;
CREATE TABLE milscm_2023_010.azn_202310_select_kanja_backborn_hd( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , hd_flg INTEGER NOT NULL                   -- ���̓t���O
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_select_kanja_backborn_hd ADD CONSTRAINT azn_202310_select_kanja_backborn_hd_pkey
 PRIMARY KEY (facility_id, himoduke_id); 

ALTER TABLE milscm_2023_010.azn_202310_select_kanja_backborn_hd OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_select_kanja_backborn_hd IS '�Z���N�g_���͗L��_���Ҕw�i�p'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kanja_backborn_hd.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kanja_backborn_hd.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kanja_backborn_hd.hd_flg IS '���̓t���O';
