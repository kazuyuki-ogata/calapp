--DROP TABLE  milscm_2023_010.azn_202310_mt_yakuzai;
CREATE TABLE milscm_2023_010.azn_202310_mt_yakuzai( 
    iyakuhin_cd TEXT NOT NULL                   -- ���i�R�[�h
    , iyakuhin_name TEXT NOT NULL               -- ���i��
    , disp_name TEXT NOT NULL                   -- �\����
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_mt_yakuzai ADD CONSTRAINT azn_202310_mt_yakuzai_pkey PRIMARY
 KEY (iyakuhin_cd); 

ALTER TABLE milscm_2023_010.azn_202310_mt_yakuzai OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_mt_yakuzai IS '��܃}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_yakuzai.iyakuhin_cd IS '���i�R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_yakuzai.iyakuhin_name IS '���i��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_yakuzai.disp_name IS '�\����';
