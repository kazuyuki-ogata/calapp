--DROP TABLE  milscm_2023_010.azn_202310_enroll_kanja;
CREATE TABLE milscm_2023_010.azn_202310_enroll_kanja( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , shikibetsu_no TEXT NOT NULL               -- �f�[�^���ʔԍ�
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_enroll_kanja ADD CONSTRAINT azn_202310_enroll_kanja_pkey
 PRIMARY KEY (facility_id, shikibetsu_no); 

ALTER TABLE milscm_2023_010.azn_202310_enroll_kanja OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_enroll_kanja IS '�g����_�Ώۊ���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_kanja.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_kanja.shikibetsu_no IS '�f�[�^���ʔԍ�';
