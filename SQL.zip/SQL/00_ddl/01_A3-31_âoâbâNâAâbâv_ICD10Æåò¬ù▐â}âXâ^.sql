--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_icd10_m;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_icd10_m( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , koshin_kubun TEXT NOT NULL                -- �X�V�敪
    , icd10_m_code TEXT NOT NULL                -- ICD10�����ރR�[�h
    , icd10_m_name TEXT NOT NULL                -- ICD10�����ޖ�
    , icd10_l_code TEXT NOT NULL                -- ICD10�啪�ރR�[�h
    , ikosaki TEXT                              -- �ڍs��
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_icd10_m ADD CONSTRAINT azn_202310_backup_mt_icd10_m_pkey
 PRIMARY KEY (sekoubi, koshin_kubun, icd10_m_code); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_icd10_m OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_icd10_m IS '�o�b�N�A�b�v_ICD10�����ރ}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.koshin_kubun IS '�X�V�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.icd10_m_code IS 'ICD10�����ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.icd10_m_name IS 'ICD10�����ޖ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.icd10_l_code IS 'ICD10�啪�ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.ikosaki IS '�ڍs��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_m.update_ymd IS '�f�[�^�o�^��';
