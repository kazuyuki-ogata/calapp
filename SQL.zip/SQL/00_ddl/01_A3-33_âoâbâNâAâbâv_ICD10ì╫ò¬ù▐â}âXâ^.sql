--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_icd10_ss;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_icd10_ss( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , koshin_kubun TEXT NOT NULL                -- �X�V�敪
    , icd10_ss_code TEXT NOT NULL               -- ICD10�ו��ރR�[�h
    , icd10_ss_name TEXT NOT NULL               -- ICD10�ו��ޖ�
    , icd10_l_code TEXT NOT NULL                -- ICD10�啪�ރR�[�h
    , icd10_m_code TEXT NOT NULL                -- ICD10�����ރR�[�h
    , icd10_s_code TEXT NOT NULL                -- ICD10�����ރR�[�h
    , ikosaki TEXT                              -- �ڍs��
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_icd10_ss ADD CONSTRAINT azn_202310_backup_mt_icd10_ss_pkey
 PRIMARY KEY (sekoubi, koshin_kubun, icd10_ss_code); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_icd10_ss OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_icd10_ss IS '�o�b�N�A�b�v_ICD10�ו��ރ}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.koshin_kubun IS '�X�V�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.icd10_ss_code IS 'ICD10�ו��ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.icd10_ss_name IS 'ICD10�ו��ޖ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.icd10_l_code IS 'ICD10�啪�ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.icd10_m_code IS 'ICD10�����ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.icd10_s_code IS 'ICD10�����ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.ikosaki IS '�ڍs��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_ss.update_ymd IS '�f�[�^�o�^��';
