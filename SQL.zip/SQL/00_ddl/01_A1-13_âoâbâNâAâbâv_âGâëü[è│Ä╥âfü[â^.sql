--DROP TABLE  milscm_2023_010.azn_202310_backup_mart_error_patient;
CREATE TABLE milscm_2023_010.azn_202310_backup_mart_error_patient( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , data_type TEXT NOT NULL                   -- �f�[�^���
    , patient_id TEXT NOT NULL                  -- ����ID
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mart_error_patient ADD CONSTRAINT azn_202310_backup_mart_error_patient_pkey
 PRIMARY KEY (facility_id, himoduke_id, data_type, patient_id); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mart_error_patient OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mart_error_patient IS '�o�b�N�A�b�v_�G���[���҃f�[�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_error_patient.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_error_patient.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_error_patient.data_type IS '�f�[�^���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mart_error_patient.patient_id IS '����ID';
