--DROP TABLE  milscm_2023_010.azn_202310_select_kanja_backborn_gappei01;
CREATE TABLE milscm_2023_010.azn_202310_select_kanja_backborn_gappei01( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , d01 INTEGER NOT NULL                      -- eGFR�t���O
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_select_kanja_backborn_gappei01 ADD CONSTRAINT azn_202310_select_kanja_backborn_gappei01_pkey
 PRIMARY KEY (facility_id, himoduke_id); 

ALTER TABLE milscm_2023_010.azn_202310_select_kanja_backborn_gappei01 OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_select_kanja_backborn_gappei01 IS '�Z���N�g_�����ǗL��_CKD_���Ҕw�i�p'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kanja_backborn_gappei01.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kanja_backborn_gappei01.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kanja_backborn_gappei01.d01 IS 'eGFR�t���O';
