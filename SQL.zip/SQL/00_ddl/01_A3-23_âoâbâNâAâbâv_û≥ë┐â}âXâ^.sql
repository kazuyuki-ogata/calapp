--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_price;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_price( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , koshin_kubun TEXT NOT NULL                -- �X�V�敪
    , iyakuhin_code TEXT NOT NULL               -- ���i�R�[�h
    , nendo TEXT NOT NULL                       -- �N�x
    , price NUMERIC NOT NULL                    -- ��
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_price ADD CONSTRAINT azn_202310_backup_mt_price_pkey
 PRIMARY KEY (sekoubi, koshin_kubun, iyakuhin_code); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_price OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_price IS '�o�b�N�A�b�v_�򉿃}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.koshin_kubun IS '�X�V�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.iyakuhin_code IS '���i�R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.nendo IS '�N�x'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.price IS '��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_price.update_ymd IS '�f�[�^�o�^��';
