--DROP TABLE  milscm_2023_010.azn_202310_select_kensa;
CREATE TABLE milscm_2023_010.azn_202310_select_kensa( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , num_value NUMERIC                         -- ���l����
    , sample_time TEXT NOT NULL                 -- �̎����
    , disp_name TEXT                            -- �\����
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_select_kensa ADD CONSTRAINT azn_202310_select_kensa_pkey
 PRIMARY KEY (facility_id, himoduke_id, sample_time); 

ALTER TABLE milscm_2023_010.azn_202310_select_kensa OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_select_kensa IS '�Z���N�g_�����f�[�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa.num_value IS '���l����'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa.sample_time IS '�̎����'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_select_kensa.disp_name IS '�\����';
