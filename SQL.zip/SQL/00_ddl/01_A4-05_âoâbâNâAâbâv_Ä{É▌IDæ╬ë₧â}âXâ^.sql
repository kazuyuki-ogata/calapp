--DROP TABLE  milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu( 
    old_facility_id TEXT NOT NULL               -- ���{��ID
    , new_facility_id TEXT NOT NULL             -- �V�{��ID
    , start_ymd TEXT DEFAULT '99999999' NOT NULL -- �K�p�J�n��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu ADD CONSTRAINT azn_202310_backup_mt2_old_new_shisetsu_pkey
 PRIMARY KEY (old_facility_id); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu IS '�o�b�N�A�b�v_�{��ID�Ή��}�X�^'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu.old_facility_id IS '���{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu.new_facility_id IS '�V�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt2_old_new_shisetsu.start_ymd IS '�K�p�J�n��';
