--DROP TABLE  milscm_2023_010.azn_202310_mt_yakuzai_mml;
CREATE TABLE milscm_2023_010.azn_202310_mt_yakuzai_mml( 
    facility_id_mml TEXT NOT NULL               -- �{��ID�iMML�j
    , medicine_name TEXT NOT NULL               -- ��ܖ���
    , iyakuhin_cd TEXT NOT NULL                 -- ���i�R�[�h
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_mt_yakuzai_mml ADD CONSTRAINT azn_202310_mt_yakuzai_mml_pkey
 PRIMARY KEY (facility_id_mml, medicine_name); 

ALTER TABLE milscm_2023_010.azn_202310_mt_yakuzai_mml OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_mt_yakuzai_mml IS 'MML��܃}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_yakuzai_mml.facility_id_mml IS '�{��ID�iMML�j'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_yakuzai_mml.medicine_name IS '��ܖ���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_yakuzai_mml.iyakuhin_cd IS '���i�R�[�h';
