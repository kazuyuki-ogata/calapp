--DROP TABLE  milscm_2023_010.azn_202310_enroll_shikkan;
CREATE TABLE milscm_2023_010.azn_202310_enroll_shikkan( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , master_id TEXT NOT NULL                   -- ����ID
    , byomei TEXT NOT NULL                      -- �a��
    , byomei_code TEXT NOT NULL                 -- �a���R�[�h�l
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_enroll_shikkan ADD CONSTRAINT azn_202310_enroll_shikkan_pkey
 PRIMARY KEY (facility_id, master_id, byomei, byomei_code); 

ALTER TABLE milscm_2023_010.azn_202310_enroll_shikkan OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_enroll_shikkan IS '�g����_�Ώێ���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shikkan.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shikkan.master_id IS '����ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shikkan.byomei IS '�a��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_enroll_shikkan.byomei_code IS '�a���R�[�h�l';
