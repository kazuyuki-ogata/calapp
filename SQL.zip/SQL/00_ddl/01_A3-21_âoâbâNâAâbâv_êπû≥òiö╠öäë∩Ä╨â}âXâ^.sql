--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , koshin_kubun TEXT NOT NULL                -- �X�V�敪
    , iyakuhin_code TEXT NOT NULL               -- ���i�R�[�h
    , maker_code TEXT NOT NULL                  -- ���[�J�R�[�h
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha ADD CONSTRAINT azn_202310_backup_mt_iyakuhin_sales_kaisha_pkey
 PRIMARY KEY ( 
    sekoubi
    , koshin_kubun
    , iyakuhin_code
    , maker_code
); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha IS '�o�b�N�A�b�v_���i�̔���Ѓ}�X�^'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha.koshin_kubun IS '�X�V�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha.iyakuhin_code IS '���i�R�[�h'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha.maker_code IS '���[�J�R�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_iyakuhin_sales_kaisha.update_ymd IS '�f�[�^�o�^��';
