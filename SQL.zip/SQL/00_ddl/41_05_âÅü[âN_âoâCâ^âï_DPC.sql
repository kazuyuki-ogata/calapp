--DROP TABLE  milscm_2023_010.azn_202310_work_vital_dpc;
CREATE TABLE milscm_2023_010.azn_202310_work_vital_dpc( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , shikibetsu_no TEXT NOT NULL               -- �f�[�^���ʔԍ�
    , category TEXT NOT NULL                    -- �J�e�S��
    , value TEXT                                -- �l
    , nyuin_ymd TEXT                            -- ���@�N����
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_work_vital_dpc ADD CONSTRAINT azn_202310_work_vital_dpc_pkey
 PRIMARY KEY (facility_id, shikibetsu_no, category); 

ALTER TABLE milscm_2023_010.azn_202310_work_vital_dpc OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_work_vital_dpc IS '���[�N_�o�C�^��_DPC'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_vital_dpc.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_vital_dpc.shikibetsu_no IS '�f�[�^���ʔԍ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_vital_dpc.category IS '�J�e�S��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_vital_dpc.value IS '�l'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_vital_dpc.nyuin_ymd IS '���@�N����';
