--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_dpc2;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_dpc2( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , henkou_kubun TEXT NOT NULL                -- �ύX�敪
    , dpc2_code TEXT NOT NULL                   -- DPC�R�[�h2��
    , dpc2_name TEXT NOT NULL                   -- DPC2����
    , ikosaki TEXT                              -- �ڍs��
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_dpc2 ADD CONSTRAINT azn_202310_backup_mt_dpc2_pkey
 PRIMARY KEY (sekoubi, dpc2_code); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_dpc2 OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_dpc2 IS '�o�b�N�A�b�v_DPC2���}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.henkou_kubun IS '�ύX�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.dpc2_code IS 'DPC�R�[�h2��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.dpc2_name IS 'DPC2����'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.ikosaki IS '�ڍs��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_dpc2.update_ymd IS '�f�[�^�o�^��';
