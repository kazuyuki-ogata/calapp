--DROP TABLE  milscm_2023_010.azn_202310_backup_mt_icd10_l;
CREATE TABLE milscm_2023_010.azn_202310_backup_mt_icd10_l( 
    sekoubi TEXT NOT NULL                       -- �{�s��
    , koshin_kubun TEXT NOT NULL                -- �X�V�敪
    , icd10_l_code TEXT NOT NULL                -- ICD10�啪�ރR�[�h
    , icd10_l_name TEXT NOT NULL                -- ICD10�啪�ޖ�
    , ikosaki TEXT                              -- �ڍs��
    , nen TEXT NOT NULL                         -- �N
    , nengetsu TEXT NOT NULL                    -- �N��
    , update_ymd TEXT NOT NULL                  -- �f�[�^�o�^��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_mt_icd10_l ADD CONSTRAINT azn_202310_backup_mt_icd10_l_pkey
 PRIMARY KEY (sekoubi, koshin_kubun, icd10_l_code); 

ALTER TABLE milscm_2023_010.azn_202310_backup_mt_icd10_l OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_mt_icd10_l IS '�o�b�N�A�b�v_ICD10�啪�ރ}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.sekoubi IS '�{�s��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.koshin_kubun IS '�X�V�敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.icd10_l_code IS 'ICD10�啪�ރR�[�h'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.icd10_l_name IS 'ICD10�啪�ޖ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.ikosaki IS '�ڍs��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.nen IS '�N'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.nengetsu IS '�N��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_mt_icd10_l.update_ymd IS '�f�[�^�o�^��';
