--DROP TABLE  milscm_2023_010.azn_202310_deli_kanja_backborn_kensa;
CREATE TABLE milscm_2023_010.azn_202310_deli_kanja_backborn_kensa( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , cate_k TEXT NOT NULL                      -- �J���E��
    , value_k NUMERIC NOT NULL                  -- �J���E���̒l
    , cate_cre TEXT NOT NULL                    -- �����N���A�`�j��
    , value_cre NUMERIC NOT NULL                -- �����N���A�`�j���̒l
    , cate_egfr TEXT NOT NULL                   -- eGFR
    , value_egfr NUMERIC NOT NULL               -- eGFR�̒l
    , cate_ntbnp TEXT NOT NULL                  -- NT-proBNP
    , value_ntbnp NUMERIC NOT NULL              -- NT-proBNP�̒l
    , cate_bnp TEXT NOT NULL                    -- BNP
    , value_bnp NUMERIC NOT NULL                -- BNP�̒l
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_deli_kanja_backborn_kensa ADD CONSTRAINT azn_202310_deli_kanja_backborn_kensa_pkey
 PRIMARY KEY (facility_id, himoduke_id); 

ALTER TABLE milscm_2023_010.azn_202310_deli_kanja_backborn_kensa OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_deli_kanja_backborn_kensa IS '�f���o��_���Ҕw�i'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.cate_k IS '�J���E��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.value_k IS '�J���E���̒l'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.cate_cre IS '�����N���A�`�j��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.value_cre IS '�����N���A�`�j���̒l'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.cate_egfr IS 'eGFR'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.value_egfr IS 'eGFR�̒l'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.cate_ntbnp IS 'NT-proBNP'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.value_ntbnp IS 'NT-proBNP�̒l'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.cate_bnp IS 'BNP'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_backborn_kensa.value_bnp IS 'BNP�̒l';
