--DROP TABLE  milscm_2023_010.azn_202310_backup_kanja_first_criteria;
CREATE TABLE milscm_2023_010.azn_202310_backup_kanja_first_criteria( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , facility_id_mml TEXT NOT NULL             -- �{��ID�iMML�j
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , data_type TEXT NOT NULL                   -- �f�[�^���
    , patient_id TEXT NOT NULL                  -- ����ID
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_backup_kanja_first_criteria ADD CONSTRAINT azn_202310_backup_kanja_first_criteria_pkey
 PRIMARY KEY (facility_id, himoduke_id, data_type, patient_id); 

ALTER TABLE milscm_2023_010.azn_202310_backup_kanja_first_criteria OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_backup_kanja_first_criteria IS '�o�b�N�A�b�v_���҃}�X�^_�g���������'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_kanja_first_criteria.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_kanja_first_criteria.facility_id_mml IS '�{��ID�iMML�j'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_kanja_first_criteria.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_kanja_first_criteria.data_type IS '�f�[�^���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_backup_kanja_first_criteria.patient_id IS '����ID';
