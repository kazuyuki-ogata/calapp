--DROP TABLE  milscm_2023_010.azn_202310_deli_kanja_bmi;
CREATE TABLE milscm_2023_010.azn_202310_deli_kanja_bmi( 
    facility_id TEXT NOT NULL                   -- �{��ID
    , himoduke_id TEXT NOT NULL                 -- �R�t��ID
    , height NUMERIC NOT NULL                   -- �g��
    , weight NUMERIC NOT NULL                   -- �̏d
    , bmi NUMERIC NOT NULL                      -- BMI
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_deli_kanja_bmi ADD CONSTRAINT azn_202310_deli_kanja_bmi_pkey
 PRIMARY KEY (facility_id, himoduke_id); 

ALTER TABLE milscm_2023_010.azn_202310_deli_kanja_bmi OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_deli_kanja_bmi IS '�f���o��_����_BMI'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_bmi.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_bmi.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_bmi.height IS '�g��'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_bmi.weight IS '�̏d'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_deli_kanja_bmi.bmi IS 'BMI';
