create table milscm_2023_010.azn_202310_select_kensa as (
select 
	basic.*, 
	mml_lb.num_value::float, 
	mml_lb.sample_time, 
	mt_kensa.disp_name 
from milscm_2023_010.azn_202310_work_kensa AS mml_lb
        INNER JOIN milscm_2023_010.azn_202310_mt_kensa AS mt_kensa 
            ON (
                mml_lb.facility_id = mt_kensa.facility_id 
                AND mml_lb.specimen_name = mt_kensa.specimen_name 
                AND mml_lb.sp_code = mt_kensa.sp_code 
                AND mml_lb.item_name = mt_kensa.item_name 
                AND mml_lb.facility_it_code = mt_kensa.item_code
        )
    INNER JOIN milscm_2023_010.azn_202310_select_patient_basic AS basic ON (
        basic.facility_id = mml_lb.facility_id
        AND basic.himoduke_id = mml_lb.himoduke_id
    )
	where mml_lb.num_value <> ''
);
