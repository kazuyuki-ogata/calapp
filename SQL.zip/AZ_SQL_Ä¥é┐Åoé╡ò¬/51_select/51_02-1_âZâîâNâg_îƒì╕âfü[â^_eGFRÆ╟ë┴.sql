INSERT INTO milscm_2023_010.azn_202310_select_kensa
select facility_id, himoduke_id, age, sex_kubun, index_date, look_back_term, shoho_start_date, shoho_end_date, shoho_term, department_list, 
case when sex_kubun = '1' then 194 * power(num_value, -1.094) * power(age::float, -0.287)
else 194 * power(num_value, -1.094) * power(age::float, -0.287) * 0.739 end AS num_value
, sample_time, 'eGFR' AS disp_name
from milscm_2023_010.azn_202310_select_kensa
where disp_name = '血清クレアチニン'
;
