-- SQL_ID : 41_02
-- ���[�N_���Ҋ�{�f�[�^_RCP_MML�o�^
-- ���Z�v�g�AMML�̊��҃f�[�^�𒊏o���A���[�N_���Ҋ�{�f�[�^_RCP_MML�e�[�u���Ɋi�[����B

WITH shohou_index AS (
SELECT
    facility_id
    , himoduke_id
    , string_agg(department_kubun, '_' ORDER BY department_kubun) AS department_list 
    , jisshi_ymd AS index_date
FROM
(
	SELECT
	    facility_id
	    , himoduke_id
	    , department_kubun
	    , jisshi_ymd 
	    , rank() over (partition by facility_id, himoduke_id order by jisshi_ymd) AS rank
	FROM
	    milscm_2023_010.azn_202310_work_shohou_index 
) AS index_rank
WHERE
    rank = 1
GROUP BY
    facility_id
    , himoduke_id
    , jisshi_ymd 
)
, term AS (
SELECT
    facility_id
    , himoduke_id
    , min(jisshi_ymd) AS shoho_start_date
    , max(to_char(jisshi_ymd::date + koi_times::int, 'YYYYMMDD')) AS shoho_end_date
FROM
    milscm_2023_010.azn_202310_work_shohou_index 
GROUP BY
    facility_id
    , himoduke_id
)
INSERT 
INTO milscm_2023_010.azn_202310_select_patient_basic 
SELECT
    basic.facility_id
    , basic.himoduke_id
    , milscm4.get_age(birthday, shohou_index.index_date) AS age
    , basic.sex_kubun
    , shohou_index.index_date
    , term.shoho_start_date::date - back.min_jisshi_ymd::date + 1 AS look_back_term
    , term.shoho_start_date
    , term.shoho_end_date
    , term.shoho_end_date::date - term.shoho_start_date::date + 1 AS shoho_term
    , shohou_index.department_list
FROM
    milscm_2023_010.azn_202310_work_patient_basic AS basic
    INNER JOIN shohou_index ON (
        basic.facility_id = shohou_index.facility_id
        AND basic.himoduke_id = shohou_index.himoduke_id
    )
    INNER JOIN term ON (
        basic.facility_id = term.facility_id
        AND basic.himoduke_id = term.himoduke_id
    )
    INNER JOIN milscm_2023_010.azn_202310_work_look_back AS back ON (
        basic.facility_id = back.facility_id
        AND basic.himoduke_id = back.himoduke_id
    )
;
