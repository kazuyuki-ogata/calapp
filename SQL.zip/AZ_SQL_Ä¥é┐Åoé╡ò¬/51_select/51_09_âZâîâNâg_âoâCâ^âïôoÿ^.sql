
create table milscm_2023_010.azn_202310_select_vital as 
select item_name, facility_id, himoduke_id, avg(vital_sign_num_value) from (
select g.facility_id, g.himoduke_id, g.item_name, g.vital_sign_num_value, g.rank as value_rank, abs(g.vital_sign_date::date - basic.index_date::date) as abs_date 
	,rank() over (partition by g.facility_id, g.himoduke_id, g.item_name order by abs(g.vital_sign_date::date - basic.index_date::date)) as date_rank
	from milscm_2023_010.azn_202310_work_vital g
	inner join (select facility_id, himoduke_id, index_date from milscm_2023_010.azn_202310_select_patient_basic) as basic
		on (basic.facility_id = g.facility_id and basic.himoduke_id = g.himoduke_id)
) s
where date_rank = 1
group by item_name, facility_id, himoduke_id