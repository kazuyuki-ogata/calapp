create table milscm_2023_010.azn_202310_select_kanja_backborn_kensa as (
select facility_id, himoduke_id, sample_time, disp_name, num_value
from (
	select *, row_number() over (partition by facility_id, himoduke_id, disp_name order by days) as row_no
	from (
		select facility_id, himoduke_id, max(age) as age, max(sex_kubun) as sex_kubun, max(index_date) as index_date, avg(num_value) as num_value, sample_time, disp_name, max(index_date)::date - sample_time as days
		from milscm_2023_010.azn_202310_select_kensa
		where sample_time between ((index_date::date) + 1 - look_back_term) and index_date::date
		group by facility_id, himoduke_id, disp_name, sample_time
	) a
) b
where b.row_no = 1
);
