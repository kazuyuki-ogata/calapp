create table milscm_2023_010.azn_202310_select_kensa_k as (
select *, days / 7::int as weeks, days / 30::int as months from (
	select *, sample_time - index_date as days from (
		select facility_id, himoduke_id, sample_time, max(index_date)::date as index_date, avg(num_value) as num_value
		from milscm_2023_010.azn_202310_select_kensa
		where disp_name = '�J���E��'
		group by facility_id, himoduke_id, sample_time
	) a
) b

);

