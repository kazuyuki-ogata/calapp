-- SQL_ID : 21_06
-- MML��ܖ��ꗗ�o�^
-- MML�̏����e�[�u������Ώۊ��҂̖�ܖ��ꗗ�𒊏o�������ʂ�MML��ܖ��ꗗ�e�[�u���Ɋi�[����B
WITH target_kanja AS ( 
    SELECT DISTINCT
        mt_kanja_id_list.facility_id_mml
        , mt_kanja_id_list.patient_id 
    FROM
        milscm_2023_007.sgioy_202310_mt_kanja_id_list AS mt_kanja_id_list 
        INNER JOIN milscm_2023_007.sgioy_202310_mt_kanja AS mt_kanja 
            ON ( 
                -- �f�[�^��ʂ�MML
                mt_kanja_id_list.data_type = 'MML' 
                AND mt_kanja_id_list.facility_id = mt_kanja.facility_id 
                AND mt_kanja_id_list.himoduke_id = mt_kanja.himoduke_id
            )
) 
, mmlps_medication AS ( 
    SELECT DISTINCT
        mml_mmlps_medication.zip_no
        , mml_mmlps_medication.file_no
        , mml_mmlps_medication.body_no
        , mml_mmlps_medication.medication_no
        , mml_mmlps_medication.facility_id_mml
        , mml_mmlps_medication.medicine_name 
    FROM
        milscm_2023_007.sgioy_202310_backup_text_mml_mmlps_medication AS mml_mmlps_medication 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                target_kanja 
            WHERE
                target_kanja.facility_id_mml = mml_mmlps_medication.facility_id_mml 
                AND target_kanja.patient_id = mml_mmlps_medication.master_id
        )
) 
, mmlps_join AS ( 
    SELECT DISTINCT
        mmlps_medication.facility_id_mml
        , mmlps_medication.medicine_name
        , COALESCE(mmlps_medicine.code, '') AS code
        , COALESCE(mmlps_medicine.system, '') AS system 
    FROM
        mmlps_medication 
        LEFT JOIN milscm_2023_007.sgioy_202310_backup_text_mml_mmlps_medicine AS mmlps_medicine 
            ON ( 
                mmlps_medication.zip_no = mmlps_medicine.zip_no 
                AND mmlps_medication.file_no = mmlps_medicine.file_no 
                AND mmlps_medication.body_no = mmlps_medicine.body_no 
                AND mmlps_medication.medication_no = mmlps_medicine.medication_no
            )
) 
, mmlps_list AS ( 
    SELECT
        facility_id_mml
        , medicine_name
        , code
        , system
        , CASE 
            WHEN code = '' 
            OR system = '' 
                THEN NULL 
            ELSE CONCAT(system, '-', code) 
            END AS medicine_code 
    FROM
        mmlps_join
) 
INSERT 
INTO milscm_2023_007.sgioy_202310_mt_yakuzai_list_mml -- �{��ID�iMML�j�A��ܖ��ŏW��
SELECT
    facility_id_mml
    , medicine_name
    , string_agg(medicine_code, '_' ORDER BY system) AS medicine_code_list 
FROM
    mmlps_list 
GROUP BY
    facility_id_mml
    , medicine_name;
