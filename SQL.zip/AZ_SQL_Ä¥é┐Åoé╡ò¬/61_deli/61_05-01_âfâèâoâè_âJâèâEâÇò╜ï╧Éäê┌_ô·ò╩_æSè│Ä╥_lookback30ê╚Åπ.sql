--drop table milscm_2023_010.azn_202310_deli_k_days_all_look30;
create table milscm_2023_010.azn_202310_deli_k_days_all_look30 as (
select 
	'ALL' as cate_egfr_summary, kensa.days, avg(num_value) as avg_value, stddev_pop(num_value) as std_value, count(*) as patient_count 
from milscm_2023_010.azn_202310_select_kensa_k kensa
inner join 
	(select *,
			case 
		when cate_egfr in ('15未満', '15-30未満') then '30未満' 
		when cate_egfr in ('45-60未満', '60以上') then '45以上'
		else '30-45未満' end as cate_egfr_summary
		from milscm_2023_010.azn_202310_deli_kanja_backborn_kensa
	) back 
	on
		kensa.facility_id = back.facility_id 
		and kensa.himoduke_id = back.himoduke_id 
		and back.cate_egfr is not null
where exists (select 1 from milscm_2023_010.azn_202310_select_patient_basic basic 
	where
		kensa.facility_id = basic.facility_id 
		and kensa.himoduke_id = basic.himoduke_id 
		and basic.age::int >= 18
		and basic.look_back_term >= 30
)
group by kensa.days
);
