create table milscm_2023_010.azn_202310_deli_kanja_bmi as (
select facility_id, himoduke_id, max(height) as height, max(weight) as weight,  max(weight) / ((max(height) / 100.00) * (max(height)/ 100.00)) as bmi
from (select facility_id, himoduke_id, case when item_name= 'Height' then avg else null end as height, 
	  case when item_name= 'Weight' then avg else null end as weight from milscm_2023_010.azn_202310_select_vital) a group by facility_id, himoduke_id
);