--DROP TABLE  milscm_2023_010.azn_202310_mt_shisetsu;
CREATE TABLE milscm_2023_010.azn_202310_mt_shisetsu( 
    facility_mask_id TEXT NOT NULL              -- �{�݃}�X�NID
    , facility_id TEXT NOT NULL                 -- �{��ID
    , facility_id_mml TEXT                      -- �{��ID�iMML�j
    , facility_name TEXT NOT NULL               -- �{�ݖ�
    , facility_contract_start TEXT              -- �{�݃f�[�^�񋟊J�n��
    , facility_contract_end TEXT                -- �{�݃f�[�^�񋟏I����
    , SIZE INTEGER                              -- �{�݋K��
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_mt_shisetsu ADD CONSTRAINT azn_202310_mt_shisetsu_pkey
 PRIMARY KEY (facility_mask_id); 

ALTER TABLE milscm_2023_010.azn_202310_mt_shisetsu OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_mt_shisetsu IS '�{�݃}�X�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shisetsu.facility_mask_id IS '�{�݃}�X�NID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shisetsu.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shisetsu.facility_id_mml IS '�{��ID�iMML�j'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shisetsu.facility_name IS '�{�ݖ�'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shisetsu.facility_contract_start IS '�{�݃f�[�^�񋟊J�n��'
; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shisetsu.facility_contract_end IS '�{�݃f�[�^�񋟏I����'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_mt_shisetsu.SIZE IS '�{�݋K��';
