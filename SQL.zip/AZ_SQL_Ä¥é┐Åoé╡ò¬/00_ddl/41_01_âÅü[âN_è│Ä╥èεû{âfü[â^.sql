--DROP TABLE  milscm_2023_010.azn_202310_work_patient_basic;
CREATE TABLE milscm_2023_010.azn_202310_work_patient_basic( 
    facility_id TEXT NOT NULL                       -- �{��ID
    , himoduke_id TEXT NOT NULL                   -- �R�t��ID
    , data_type TEXT NOT NULL                   -- �f�[�^���
    , sex_kubun TEXT NOT NULL                   -- �j���敪
    , birthday TEXT NOT NULL                    -- ���N����
); 

ALTER TABLE ONLY milscm_2023_010.azn_202310_work_patient_basic ADD CONSTRAINT azn_202310_work_patient_basic_pkey
 PRIMARY KEY (facility_id, himoduke_id, data_type); 

ALTER TABLE milscm_2023_010.azn_202310_work_patient_basic OWNER TO pgmisgrp1; 

COMMENT 
    ON TABLE milscm_2023_010.azn_202310_work_patient_basic IS '���[�N_���Ҋ�{�f�[�^'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_patient_basic.facility_id IS '�{��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_patient_basic.himoduke_id IS '�R�t��ID'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_patient_basic.data_type IS '�f�[�^���'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_patient_basic.sex_kubun IS '�j���敪'; 

COMMENT 
    ON COLUMN milscm_2023_010.azn_202310_work_patient_basic.birthday IS '���N����';
