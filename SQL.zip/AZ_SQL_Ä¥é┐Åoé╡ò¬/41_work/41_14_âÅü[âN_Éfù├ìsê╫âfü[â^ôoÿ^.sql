-- SQL_ID : 41_14
-- ���[�N_�f�Ís�׃f�[�^�o�^
-- �f�Ís�׃f�[�^�𒊏o���A���[�N_�f�Ís�׃f�[�^�e�[�u���Ɋi�[����B
create table milscm_2023_010.azn_202310_work_shinryou_koui as 

WITH base_shinryou_koui AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , COALESCE(receipt_densan_code, '') AS receipt_densan_code
        , jisshi_ymd 
    FROM
        milscm_2023_010.azn_202310_base_mart_shinryou_koui
) 
    SELECT
        base_shinryou_koui.facility_id
        , base_shinryou_koui.shikibetsu_no as himoduke_id
        , base_shinryou_koui.receipt_densan_code
        , base_shinryou_koui.jisshi_ymd 
    FROM
        base_shinryou_koui 
        inner join milscm_2023_010.azn_202310_mt_shinryo_koi AS mt_shinryo_koi 
        on (base_shinryou_koui.receipt_densan_code = mt_shinryo_koi.shinryo_koi_cd)
