-- SQL_ID : 41_17
-- ���[�N_���̌����f�[�^�o�^
-- MML�̌��̌����f�[�^�𒊏o���A���[�N_���̌����f�[�^�e�[�u���Ɋi�[����B
WITH kensa AS ( 
    SELECT
        kensa_scm2.mask_id
        , kensa_scm2.specimen_name
        , kensa_scm2.sp_code
        , kensa_scm2.item_name
        , kensa_scm2.facility_it_code
        , kensa_scm2.unit
        , 
        LEFT (kensa_scm2.sample_time, 8) ::DATE AS sample_time
        , kensa_scm2.value
        , kensa_scm2.num_value 
	    , rank() over (partition by mask_id, specimen_name, sp_code, item_name, facility_it_code, unit, LEFT (sample_time, 8) ::DATE order by sample_time desc) AS row_no 
    FROM
        milscm_2023_010.azn_202310_work_kensa_scm2 AS kensa_scm2 
    WHERE
        kensa_scm2.row_no = 1
    UNION ALL 
    SELECT
        kensa_scm4.mask_id
        , kensa_scm4.specimen_name
        , kensa_scm4.sp_code
        , kensa_scm4.item_name
        , kensa_scm4.facility_it_code
        , kensa_scm4.unit
        , kensa_scm4.sample_time ::DATE
        , kensa_scm4.value
        , kensa_scm4.num_value 
	    , rank() over (partition by mask_id, specimen_name, sp_code, item_name, facility_it_code, unit, sample_time ::DATE order by sample_time desc) AS row_no 
    FROM
        milscm_2023_010.azn_202310_work_kensa_scm4 AS kensa_scm4
    WHERE
        kensa_scm4.row_no = 1
) 
, kanja AS ( 
    SELECT
        id_list.facility_id
        , id_list.himoduke_id
        , mt_kanja.mask_id 
    FROM
        milscm_2023_010.azn_202310_mt_kanja_id_list AS id_list 
        INNER JOIN milscm_2023_010.azn_202310_mt_kanja AS mt_kanja 
            ON ( 
                id_list.facility_id = mt_kanja.facility_id 
                AND id_list.himoduke_id = mt_kanja.himoduke_id
            )
    WHERE
        -- �f�[�^��ʂ�MML
        id_list.data_type = 'MML'
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_kensa 
SELECT
    kanja.facility_id
    , kanja.himoduke_id
    , kensa.specimen_name
    , kensa.sp_code
    , kensa.item_name
    , kensa.facility_it_code
    , kensa.unit
    , kensa.sample_time
    , kensa.value
    , kensa.num_value 
    , kensa.row_no 
FROM
    kensa
    INNER JOIN kanja ON kensa.mask_id = kanja.mask_id;
