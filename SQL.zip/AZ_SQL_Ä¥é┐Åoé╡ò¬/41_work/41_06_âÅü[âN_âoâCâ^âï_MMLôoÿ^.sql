create table milscm_2023_010.azn_202310_work_vital_mml as 
select vital.facility_id, kanja.himoduke_id, item.item_name, item.vital_sign_num_value, left(vital.vital_sign_time, 8) as vital_sign_date from (
(select * from milscm_2023_010.azn_202310_base_merge_mml_vs_vitalsign) vital
inner join 
(select * from milscm_2023_010.azn_202310_base_merge_mml_vs_item where item_name in ('Height', 'Weight')) item
	on (vital.facility_id = item.facility_id and vital.master_id = item.master_id and vital.uid = item.uid and vital.vital_seq = item.vital_seq)
)
inner join 
(select * from milscm_2023_010.azn_202310_mt_kanja_id_list where data_type = 'MML') kanja on (vital.facility_id = kanja.facility_id and vital.master_id = kanja.patient_id)
 where coalesce(item.vital_sign_num_value, '') <> ''
