-- SQL_ID : 41_15
-- ���[�N_���̌����f�[�^_�X�L�[�}2�o�^
-- MML�̌��̌����f�[�^�𒊏o���A���[�N_���̌����f�[�^_�X�L�[�}2�e�[�u���Ɋi�[����B
WITH merge_mml_lb_test AS ( 
    SELECT 
        facility_id
        , master_id
        , uid
        , kenreki_seq
        , COALESCE(sample_time, '') AS sample_time 
        , COALESCE(uketsuke_time, '') AS uketsuke_time 
        , COALESCE(report_time, '') AS report_time 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_lb_test
    WHERE
        status_code = 'final' or status = '�ŏI��'
) 
, merge_mml_lb_specimen_temp AS ( 
    SELECT 
        facility_id
        , master_id
        , uid
        , kenreki_seq
        , labo_test_seq
        , COALESCE(specimen_name, '') AS specimen_name
        , COALESCE(sp_code, '') AS sp_code 
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_lb_specimen
) 
, merge_mml_lb_specimen AS ( 
    SELECT
        merge_mml_lb_specimen_temp.facility_id
        , merge_mml_lb_specimen_temp.master_id
        , merge_mml_lb_specimen_temp.uid
        , merge_mml_lb_specimen_temp.kenreki_seq
        , merge_mml_lb_specimen_temp.labo_test_seq
        , merge_mml_lb_specimen_temp.specimen_name
        , merge_mml_lb_specimen_temp.sp_code 
    FROM
        merge_mml_lb_specimen_temp 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_mt_kensa AS mt_kensa 
            WHERE
                merge_mml_lb_specimen_temp.facility_id = mt_kensa.facility_id 
                AND merge_mml_lb_specimen_temp.specimen_name = mt_kensa.specimen_name 
                AND merge_mml_lb_specimen_temp.sp_code = mt_kensa.sp_code
        )
) 
, merge_mml_lb_item_temp AS ( 
    SELECT 
        facility_id
        , master_id
        , uid
        , kenreki_seq
        , labo_test_seq
        , COALESCE(item_name, '') AS item_name
        , COALESCE(facility_it_code, '') AS facility_it_code
        , COALESCE(unit, '') AS unit
        , COALESCE(value, '') AS value
        , COALESCE(num_value, '') AS num_value
    FROM
        milscm_2023_010.azn_202310_base_merge_mml_lb_item
) 
, merge_mml_lb_item AS ( 
    SELECT
        merge_mml_lb_item_temp.facility_id
        , merge_mml_lb_item_temp.master_id
        , merge_mml_lb_item_temp.uid
        , merge_mml_lb_item_temp.kenreki_seq
        , merge_mml_lb_item_temp.labo_test_seq
        , merge_mml_lb_item_temp.item_name
        , merge_mml_lb_item_temp.facility_it_code
        , merge_mml_lb_item_temp.unit
        , merge_mml_lb_item_temp.value
        , merge_mml_lb_item_temp.num_value
    FROM
        merge_mml_lb_item_temp 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_mt_kensa AS mt_kensa 
            WHERE
                merge_mml_lb_item_temp.facility_id = mt_kensa.facility_id 
                AND merge_mml_lb_item_temp.item_name = mt_kensa.item_name 
                AND merge_mml_lb_item_temp.facility_it_code = mt_kensa.item_code
        )
) 
, mml_lb_join AS ( 
    SELECT
        merge_mml_lb_test.facility_id
        , merge_mml_lb_test.master_id
        , merge_mml_lb_specimen.specimen_name
        , merge_mml_lb_specimen.sp_code
        , merge_mml_lb_item.item_name
        , merge_mml_lb_item.facility_it_code
        , merge_mml_lb_item.unit
        , merge_mml_lb_test.sample_time
        , merge_mml_lb_item.value
        , merge_mml_lb_item.num_value
    FROM
        merge_mml_lb_test 
        INNER JOIN merge_mml_lb_specimen 
            ON ( 
                merge_mml_lb_test.facility_id = merge_mml_lb_specimen.facility_id 
                AND merge_mml_lb_test.master_id = merge_mml_lb_specimen.master_id 
                AND merge_mml_lb_test.uid = merge_mml_lb_specimen.uid 
                AND merge_mml_lb_test.kenreki_seq = merge_mml_lb_specimen.kenreki_seq
            ) 
        INNER JOIN merge_mml_lb_item 
            ON ( 
                merge_mml_lb_specimen.facility_id = merge_mml_lb_item.facility_id 
                AND merge_mml_lb_specimen.master_id = merge_mml_lb_item.master_id 
                AND merge_mml_lb_specimen.uid = merge_mml_lb_item.uid 
                AND merge_mml_lb_specimen.kenreki_seq = merge_mml_lb_item.kenreki_seq 
                AND merge_mml_lb_specimen.labo_test_seq = merge_mml_lb_item.labo_test_seq
            )
) 
, mml_lb AS ( 
    SELECT
        mml_lb_join.facility_id
        , mml_lb_join.master_id
        , mml_lb_join.specimen_name
        , mml_lb_join.sp_code
        , mml_lb_join.item_name
        , mml_lb_join.facility_it_code
        , mml_lb_join.unit
        , mml_lb_join.sample_time
        , mml_lb_join.value
        , mml_lb_join.num_value
    FROM
        mml_lb_join 
    WHERE
        EXISTS ( 
            SELECT
                1 
            FROM
                milscm_2023_010.azn_202310_mt_kensa AS mt_kensa 
            WHERE
                mml_lb_join.facility_id = mt_kensa.facility_id 
                AND mml_lb_join.specimen_name = mt_kensa.specimen_name 
                AND mml_lb_join.sp_code = mt_kensa.sp_code 
                AND mml_lb_join.item_name = mt_kensa.item_name 
                AND mml_lb_join.facility_it_code = mt_kensa.item_code
        )
) 
, id_list AS ( 
    SELECT
        * 
    FROM
        milscm_2023_010.azn_202310_mt_kanja_id_list 
    WHERE
        -- �f�[�^��ʂ�MML
        data_type = 'MML'
) 
, mt_kanja AS ( 
    SELECT
        * 
    FROM
        milscm_2023_010.azn_202310_mt_kanja
) 
, kanja AS ( 
    SELECT
        id_list.facility_id
        , id_list.patient_id
        , mt_kanja.mask_id 
    FROM
        id_list 
        INNER JOIN mt_kanja 
            ON ( 
                id_list.facility_id = mt_kanja.facility_id 
                AND id_list.himoduke_id = mt_kanja.himoduke_id
            )
) 
INSERT 
INTO milscm_2023_010.azn_202310_work_kensa_scm2 
SELECT
    kanja.mask_id
    , mml_lb.specimen_name
    , mml_lb.sp_code
    , mml_lb.item_name
    , mml_lb.facility_it_code
    , mml_lb.unit
    , mml_lb.sample_time
    , mml_lb.value
    , mml_lb.num_value
    , rank() over (partition by kanja.mask_id, mml_lb.specimen_name, mml_lb.sp_code, mml_lb.item_name, mml_lb.facility_it_code, mml_lb.unit, mml_lb.sample_time order by mml_lb.sample_time desc, mml_lb.sample_time desc)
FROM
    mml_lb 
    INNER JOIN kanja 
        ON ( 
            mml_lb.facility_id = kanja.facility_id 
            AND mml_lb.master_id = kanja.patient_id
        );
