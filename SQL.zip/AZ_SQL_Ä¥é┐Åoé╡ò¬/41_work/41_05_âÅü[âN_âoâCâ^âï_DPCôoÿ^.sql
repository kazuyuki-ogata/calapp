create table milscm_2023_010.azn_202310_work_vital_dpc as 
select distinct facility_id, shikibetsu_no, category, value, a000020_nyuin_ymd as nyuin_ymd
from (
select facility_id, shikibetsu_no, unnest(array['Height', 'Weight']) as category, unnest(array[a001010_height, a001010_weight]) as value, a000020_nyuin_ymd
 from milscm_2023_010.azn_202310_base_merge_dpc_ff1
) a
where coalesce(value, '') <> ''