-- SQL_ID : 41_12
-- ���[�N_�����f�[�^_DPC�o�^
-- �����iDPC�j�f�[�^�𒊏o���A���[�N_�����f�[�^_DPC�e�[�u���Ɋi�[����B
create table milscm_2023_010.azn_202310_work_shohou as

WITH base_shohou AS ( 
    SELECT DISTINCT
        facility_id
        , shikibetsu_no
        , COALESCE(receipt_densan_code, '') AS receipt_densan_code
        , shiyoryo
        , unit
        , koi_times
        , jisshi_ymd 
    FROM
        milscm_2023_010.azn_202310_base_mart_shohou
) 
    SELECT
        base_shohou.facility_id
        , base_shohou.shikibetsu_no as himoduke_id
        , base_shohou.receipt_densan_code
        , base_shohou.shiyoryo
        , base_shohou.unit
        , base_shohou.koi_times
        , base_shohou.jisshi_ymd 
        , mt_yakuzai.disp_name
    FROM
        base_shohou 
        inner join milscm_2023_010.azn_202310_mt_yakuzai_heiyou AS mt_yakuzai 
        on (base_shohou.receipt_densan_code = mt_yakuzai.iyakuhin_cd)
