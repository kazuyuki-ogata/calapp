create table milscm_2023_010.azn_202310_work_vital as 
select facility_id, himoduke_id, item_name, vital_sign_num_value::float, vital_sign_date, rank() over(partition by facility_id, himoduke_id, item_name, vital_sign_date order by vital_sign_num_value::float) from (
	select * from milscm_2023_010.azn_202310_work_vital_mml where vital_sign_num_value::float <> 0
	union
	select * from milscm_2023_010.azn_202310_work_vital_dpc where value::float <> 0
) u
